/*
* Copyright 2014-2021 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
*/

/**
 * Vendored from io.ktor:ktor-server-netty:3.5.2.
 */

package com.ismartcoding.plain.lib.ktorserver

import com.ismartcoding.plain.lib.ktorserver.core.request.*
import io.netty.handler.codec.http.cookie.*

internal class NettyApplicationRequestCookies(request: PipelineRequest) : RequestCookies(request) {
    override fun fetchCookies(): Map<String, String> {
        val cookieHeaders = request.headers.getAll("Cookie") ?: return emptyMap()
        val map = HashMap<String, String>(cookieHeaders.size)
        for (cookieHeader in cookieHeaders) {
            ServerCookieDecoder.LAX.decode(cookieHeader).associateByTo(map, { it.name() }, { it.value() })
        }
        return map
    }
}
