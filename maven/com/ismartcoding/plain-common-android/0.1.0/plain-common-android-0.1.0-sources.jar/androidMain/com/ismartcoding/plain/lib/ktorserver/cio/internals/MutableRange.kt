/*
* Copyright 2014-2021 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
*/
/**
 * Vendored from io.ktor:ktor-http-cio:3.5.2.
 */

package com.ismartcoding.plain.lib.ktorserver.cio.internals

/**
 * A text range with mutable bounds
 *
 *
 * @param start points to the first character
 * @param end points to the next character after the last one
 */
public class MutableRange(public var start: Int, public var end: Int) {
    override fun toString(): String = "MutableRange(start=$start, end=$end)"
}
