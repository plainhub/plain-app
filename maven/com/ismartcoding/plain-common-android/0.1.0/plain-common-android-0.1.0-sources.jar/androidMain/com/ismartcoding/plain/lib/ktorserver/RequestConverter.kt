/*
 * Copyright 2014-2022 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package com.ismartcoding.plain.lib.ktorserver

import io.ktor.http.*
import io.ktor.http.content.*
import com.ismartcoding.plain.lib.ktorserver.core.application.*
import com.ismartcoding.plain.lib.ktorserver.core.plugins.*
import com.ismartcoding.plain.lib.ktorserver.core.request.*
import io.ktor.util.reflect.*
import io.ktor.utils.io.*
import io.ktor.utils.io.charsets.*

internal fun PluginBuilder<ContentNegotiationConfig>.convertRequestBody() {
    onCallReceive { call ->
        val registrations = pluginConfig.registrations
        val requestedType = call.receiveType

        if (requestedType.type in pluginConfig.ignoredTypes) {
            CONTENT_NEGOTIATION_LOGGER.trace(
                "Skipping for request type ${requestedType.type} because the type is ignored."
            )
            return@onCallReceive
        }

        transformBody { body: ByteReadChannel ->
            val requestContentType = try {
                call.request.contentType().withoutParameters()
            } catch (parseFailure: BadContentTypeFormatException) {
                throw BadRequestException(
                    "Illegal Content-Type header format: ${call.request.headers[HttpHeaders.ContentType]}",
                    parseFailure
                )
            }

            val charset = call.request.contentCharset() ?: Charsets.UTF_8
            for (registration in registrations) {
                return@transformBody convertBody(body, charset, registration, requestedType, requestContentType)
                    ?: continue
            }

            CONTENT_NEGOTIATION_LOGGER.trace("No suitable content converter found for request type ${requestedType.type}")
            return@transformBody body
        }
    }
}

private suspend fun convertBody(
    body: ByteReadChannel,
    charsets: Charset,
    registration: ConverterRegistration,
    receiveType: TypeInfo,
    requestContentType: ContentType
): Any? {
    if (!requestContentType.match(registration.contentType.withoutParameters())) {
        CONTENT_NEGOTIATION_LOGGER.trace(
            "Skipping content converter for request type ${receiveType.type} because " +
                "content type $requestContentType does not match ${registration.contentType}"
        )
        return null
    }

    val isEmpty = body.isClosedForRead || !body.awaitContent()
    val isNullable = receiveType.kotlinType?.isMarkedNullable == true
    if (isEmpty && isNullable) {
        return NullBody
    }

    val convertedBody = try {
        registration.converter.deserialize(charsets, receiveType, body)
    } catch (cause: Throwable) {
        throw BadRequestException("Failed to convert request body to ${receiveType.type}", cause)
    }
    return convertedBody ?: if (isNullable) NullBody else null
}
