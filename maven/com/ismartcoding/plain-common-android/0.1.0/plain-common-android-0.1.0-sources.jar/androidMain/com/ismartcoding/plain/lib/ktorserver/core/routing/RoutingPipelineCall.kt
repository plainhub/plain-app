/*
 * Copyright 2014-2019 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

/**
 * Vendored from io.ktor:ktor-server-core:3.5.2.
 */

package com.ismartcoding.plain.lib.ktorserver.core.routing

import io.ktor.http.*
import com.ismartcoding.plain.lib.ktorserver.core.application.*
import com.ismartcoding.plain.lib.ktorserver.core.request.*
import com.ismartcoding.plain.lib.ktorserver.core.response.*
import io.ktor.util.*
import kotlinx.coroutines.*
import kotlin.coroutines.*

/**
 * An application call handled by [RoutingRoot].
 *
 *
 * @property call original call from [io.ktor.server.engine.ApplicationEngine]
 * @property route is the selected route
 */
public class RoutingPipelineCall(
    public val engineCall: PipelineCall,
    public val route: RoutingNode,
    override val coroutineContext: CoroutineContext,
    receivePipeline: ApplicationReceivePipeline,
    responsePipeline: ApplicationSendPipeline,
    public val pathParameters: Parameters
) : PipelineCall, CoroutineScope {
    @Deprecated(level = DeprecationLevel.WARNING, message = "Use explicit coroutineContext instead.")
    public constructor(
        engineCall: PipelineCall,
        route: RoutingNode,
        receivePipeline: ApplicationReceivePipeline,
        responsePipeline: ApplicationSendPipeline,
        pathParameters: Parameters
    ) : this(
        engineCall,
        route,
        engineCall.coroutineContext,
        receivePipeline,
        responsePipeline,
        pathParameters
    )

    override val application: Application get() = engineCall.application
    override val attributes: Attributes get() = engineCall.attributes

    override val request: RoutingPipelineRequest =
        RoutingPipelineRequest(this, receivePipeline, engineCall.request)

    override val response: RoutingPipelineResponse =
        RoutingPipelineResponse(this, responsePipeline, engineCall.response)

    override val parameters: Parameters by lazy(LazyThreadSafetyMode.NONE) {
        Parameters.build {
            appendAll(engineCall.parameters)
            appendMissing(pathParameters)
        }
    }

    override fun toString(): String = "RoutingApplicationCall(route=$route)"
}

/**
 * An application request handled by [RoutingRoot].
 *
 */
public class RoutingPipelineRequest(
    override val call: RoutingPipelineCall,
    override val pipeline: ApplicationReceivePipeline,
    public val engineRequest: PipelineRequest
) : PipelineRequest by engineRequest

/**
 * An application response handled by [RoutingRoot].
 *
 */
public class RoutingPipelineResponse(
    override val call: RoutingPipelineCall,
    override val pipeline: ApplicationSendPipeline,
    public val engineResponse: PipelineResponse
) : PipelineResponse by engineResponse
