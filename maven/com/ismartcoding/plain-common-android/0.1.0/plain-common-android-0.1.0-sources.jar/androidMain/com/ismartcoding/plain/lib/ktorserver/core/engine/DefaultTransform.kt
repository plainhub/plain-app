/*
* Copyright 2014-2021 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
*/

/**
 * Vendored from io.ktor:ktor-server-core:3.5.2.
 */

package com.ismartcoding.plain.lib.ktorserver.core.engine

import io.ktor.http.*
import io.ktor.http.content.*
import com.ismartcoding.plain.lib.ktorserver.core.application.*
import com.ismartcoding.plain.lib.ktorserver.core.http.content.*
import com.ismartcoding.plain.lib.ktorserver.core.plugins.*
import com.ismartcoding.plain.lib.ktorserver.core.request.*
import com.ismartcoding.plain.lib.ktorserver.core.response.*
import io.ktor.util.logging.*
import io.ktor.util.pipeline.*
import io.ktor.utils.io.*
import io.ktor.utils.io.charsets.*
import io.ktor.utils.io.core.*
import kotlinx.io.*

internal val LOGGER = KtorSimpleLogger("io.ktor.server.engine.DefaultTransform")

/**
 * Default send transformation
 *
 */
public fun ApplicationSendPipeline.installDefaultTransformations() {
    intercept(ApplicationSendPipeline.Render) { value ->
        val transformed = transformDefaultContent(call, value)
        if (transformed != null) proceedWith(transformed)
    }
}

/**
 * Default receive transformation
 *
 */
public fun ApplicationReceivePipeline.installDefaultTransformations() {
    intercept(ApplicationReceivePipeline.Transform) { body ->
        val channel = body as? ByteReadChannel ?: return@intercept

        val transformed: Any? = when (call.receiveType.type) {
            ByteReadChannel::class -> null

            ByteArray::class -> channel.toByteArray()

            Parameters::class -> {
                val contentType = withContentType(call) { call.request.contentType() }
                when {
                    contentType.match(ContentType.Application.FormUrlEncoded) -> {
                        val string = channel.readText(charset = call.request.contentCharset() ?: Charsets.UTF_8)
                        parseQueryString(string)
                    }

                    contentType.match(ContentType.MultiPart.FormData) -> {
                        Parameters.build {
                            multiPartData(channel).forEachPart { part ->
                                if (part is PartData.FormItem) {
                                    part.name?.let { partName ->
                                        append(partName, part.value)
                                    }
                                }

                                part.release()
                            }
                        }
                    }

                    else -> null // Respond UnsupportedMediaType? but what if someone else later would like to do it?
                }
            }

            else -> defaultPlatformTransformations(body)
        }
        if (transformed != null) {
            LOGGER.trace("Transformed ${body::class} to ${transformed::class} for ${call.request.uri}")
            proceedWith(transformed)
        } else {
            LOGGER.trace(
                "No Default Transformations found for ${body::class} and expected type ${call.receiveType} " +
                    "for call ${call.request.uri}"
            )
        }
    }
    val afterTransform = PipelinePhase("AfterTransform")
    insertPhaseAfter(ApplicationReceivePipeline.Transform, afterTransform)
    intercept(afterTransform) { body ->
        val channel = body as? ByteReadChannel ?: return@intercept
        if (call.receiveType.type != String::class) return@intercept
        val charset = withContentType(call) { call.request.contentCharset() } ?: Charsets.UTF_8
        val text = channel.readText(charset)
        proceedWith(text)
    }
}



internal inline fun <R> withContentType(call: PipelineCall, block: () -> R): R = try {
    block()
} catch (parseFailure: BadContentTypeFormatException) {
    throw BadRequestException(
        "Illegal Content-Type header format: ${call.request.headers[HttpHeaders.ContentType]}",
        parseFailure
    )
}

internal suspend fun ByteReadChannel.readText(charset: Charset): String =
    readBuffer().readText(charset)
