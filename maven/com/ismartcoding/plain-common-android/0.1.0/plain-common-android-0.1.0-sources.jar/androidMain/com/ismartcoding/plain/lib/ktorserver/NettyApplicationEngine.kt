/*
* Copyright 2014-2021 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
*/

/**
 * Vendored from io.ktor:ktor-server-netty:3.5.2.
 */

package com.ismartcoding.plain.lib.ktorserver

import com.ismartcoding.plain.lib.ktorserver.events.*
import com.ismartcoding.plain.lib.ktorserver.core.application.*
import com.ismartcoding.plain.lib.ktorserver.core.engine.*
import io.ktor.util.network.*
import io.ktor.util.pipeline.*
import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.Channel
import io.netty.channel.ChannelOption
import io.netty.channel.ChannelPipeline
import io.netty.channel.EventLoopGroup
import io.netty.channel.epoll.Epoll
import io.netty.channel.epoll.EpollServerSocketChannel
import io.netty.channel.kqueue.KQueue
import io.netty.channel.kqueue.KQueueServerSocketChannel
import io.netty.channel.socket.ServerSocketChannel
import io.netty.channel.socket.nio.NioServerSocketChannel
import io.netty.handler.codec.http.HttpObjectDecoder
import io.netty.handler.codec.http.HttpServerCodec
import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.TimeUnit
import kotlin.reflect.KClass
import kotlin.system.measureTimeMillis

private val AFTER_CALL_PHASE = PipelinePhase("After")

/**
 * [ApplicationEngine] implementation for running in a standalone Netty
 *
 */
public class NettyApplicationEngine(
    environment: ApplicationEnvironment,
    monitor: Events,
    developmentMode: Boolean,
    public val configuration: Configuration,
    private val applicationProvider: () -> Application
) : BaseApplicationEngine(environment, monitor, developmentMode) {

    /**
     * Configuration for the [NettyApplicationEngine]
     *
     */
    public class Configuration : BaseApplicationEngine.Configuration() {

        /**
         * Number of concurrently running requests from the same http pipeline
         *
         */
        public var runningLimit: Int = 32

        /**
         * Do not create separate call event group and reuse worker group for processing calls
         *
         */
        public var shareWorkGroup: Boolean = false

        /**
         * User-provided function to configure Netty's [ServerBootstrap]
         *
         */
        public var configureBootstrap: ServerBootstrap.() -> Unit = {}

        /**
         * Timeout in seconds for sending responses to client
         *
         */
        public var responseWriteTimeoutSeconds: Int = 10

        /**
         * Timeout in seconds for reading requests from client, "0" is infinite.
         *
         */
        public var requestReadTimeoutSeconds: Int = 0

        /**
         * If set to `true`, enables TCP keep alive for connections so all
         * dead client connections will be discarded.
         * The timeout period is configured by the system so configure
         * your host accordingly.
         *
         */
        public var tcpKeepAlive: Boolean = false

        /**
         * The url limit including query parameters
         *
         */
        public var maxInitialLineLength: Int = HttpObjectDecoder.DEFAULT_MAX_INITIAL_LINE_LENGTH

        /**
         * The maximum length of all headers.
         * If the sum of the length of each header exceeds this value, a TooLongFrameException will be raised.
         *
         */
        public var maxHeaderSize: Int = HttpObjectDecoder.DEFAULT_MAX_HEADER_SIZE

        /**
         * The maximum length of the content or each chunk
         *
         */
        public var maxChunkSize: Int = HttpObjectDecoder.DEFAULT_MAX_CHUNK_SIZE

        /**
         * User-provided function to configure Netty's [HttpServerCodec]
         *
         */
        public var httpServerCodec: () -> HttpServerCodec = this::defaultHttpServerCodec

        /**
         * User-provided function to configure Netty's [ChannelPipeline]
         *
         */
        public var channelPipelineConfig: ChannelPipeline.() -> Unit = {}

        /**
         * Default function to configure Netty's
         */
        private fun defaultHttpServerCodec() = HttpServerCodec(
            maxInitialLineLength,
            maxHeaderSize,
            maxChunkSize
        )
    }

    /**
     * [EventLoopGroupProxy] for accepting connections
     */
    private val connectionEventGroup: EventLoopGroup by lazy {
        customBootstrap.config().group() ?: EventLoopGroupProxy.create(configuration.connectionGroupSize)
    }

    /**
     * [EventLoopGroupProxy] for processing incoming requests and doing engine's internal work
     */
    private val workerEventGroup: EventLoopGroup by lazy {
        customBootstrap.config().childGroup()?.let {
            return@lazy it
        }
        if (configuration.shareWorkGroup) {
            EventLoopGroupProxy.create(configuration.workerGroupSize + configuration.callGroupSize)
        } else {
            EventLoopGroupProxy.create(configuration.workerGroupSize)
        }
    }

    private val customBootstrap: ServerBootstrap by lazy {
        ServerBootstrap().apply(configuration.configureBootstrap)
    }

    /**
     * [EventLoopGroupProxy] for processing [PipelineCall] instances
     */
    private val callEventGroup: EventLoopGroup by lazy {
        if (configuration.shareWorkGroup) {
            workerEventGroup
        } else {
            EventLoopGroupProxy.create(configuration.callGroupSize)
        }
    }

    private val workerDispatcher by lazy {
        workerEventGroup.asCoroutineDispatcher()
    }

    private var cancellationJob: CompletableJob? = null

    private var channels: List<Channel>? = null
    internal val bootstraps: List<ServerBootstrap> by lazy {
        configuration.connectors.map(::createBootstrap)
    }

    private fun createBootstrap(connector: EngineConnectorConfig): ServerBootstrap {
        return customBootstrap.clone().apply {
            if (config().group() == null && config().childGroup() == null) {
                group(connectionEventGroup, workerEventGroup)
            }

            if (config().channelFactory() == null) {
                channel(getChannelClass().java)
            }

            val userContext =
                NettyApplicationCallHandler.CallHandlerCoroutineName +
                    NettyDispatcher +
                    DefaultUncaughtExceptionHandler(environment.log)

            childHandler(
                NettyChannelInitializer(
                    applicationProvider,
                    pipeline,
                    environment,
                    callEventGroup,
                    workerDispatcher,
                    userContext,
                    connector,
                    configuration.runningLimit,
                    configuration.responseWriteTimeoutSeconds,
                    configuration.requestReadTimeoutSeconds,
                    configuration.httpServerCodec,
                    configuration.channelPipelineConfig,
                )
            )
            // Send small responses immediately instead of waiting for Nagle
            childOption(ChannelOption.TCP_NODELAY, true)
            // Rebind immediately after stop even when accepted sockets linger in
            // TIME_WAIT (a web session closed just before a restart would
            // otherwise block the bind for the full TIME_WAIT duration).
            option(ChannelOption.SO_REUSEADDR, true)
            // Deep send buffer so large media responses can fill the WiFi bandwidth-delay
            // product; the kernel doubles this value and clamps it to net.core.wmem_max,
            // so over-requesting only loses the excess.
            childOption(ChannelOption.SO_SNDBUF, 1024 * 1024)
            if (configuration.tcpKeepAlive) {
                childOption(ChannelOption.SO_KEEPALIVE, true)
            }
        }
    }

    init {
        pipeline.insertPhaseAfter(EnginePipeline.Call, AFTER_CALL_PHASE)
        pipeline.intercept(AFTER_CALL_PHASE) {
            // [NettyApplicationCall.finish] is non-suspending: it only ensures the response is
            // committed (headers + status flushed). The actual write completion is awaited via
            // structured concurrency — the call's responseWriteJob is a child of the call's
            // coroutine Job, so the call coroutine remains "completing" until the I/O-thread
            // writer finishes and cleanup runs from responseWriteJob's invokeOnCompletion handler.
            (call as? NettyApplicationCall)?.finish()
        }
    }

    override fun start(wait: Boolean): NettyApplicationEngine {
        // Bind one connector at a time and track what bound: if a later
        // connector fails (e.g. its port is in use), the earlier channels must
        // be closed here — the `channels` assignment below never happens, so
        // nobody else holds a reference and the socket would stay open until
        // process death, making every later start report the port as occupied.
        val bound = mutableListOf<Channel>()
        try {
            for ((bootstrap, connector) in bootstraps.zip(configuration.connectors)) {
                bound += bootstrap.bind(connector.host, connector.port).sync().channel()
            }
            channels = bound
            val connectors = bound.zip(configuration.connectors)
                .map { it.second.withPort(it.first.localAddress().port) }
            resolvedConnectorsDeferred.complete(connectors)
        } catch (cause: Throwable) {
            bound.forEach { withStopException { it.close().sync() } }
            terminate()
            throw cause
        }

        monitor.raiseCatching(ServerReady, environment, environment.log)

        cancellationJob = stopServerOnCancellation(
            applicationProvider(),
            configuration.shutdownGracePeriod,
            configuration.shutdownTimeout
        )

        if (wait) {
            channels?.map { it.closeFuture() }?.forEach { it.sync() }
            stop(configuration.shutdownGracePeriod, configuration.shutdownTimeout)
        }
        return this
    }

    private fun terminate() {
        // Startup failed (e.g. port already in use): no connection was ever
        // accepted, so there is nothing to drain. The no-arg shutdownGracefully()
        // uses Netty's default 2s quiet period per group (~4s here) which stalled
        // the UI's ERROR state on every port conflict — shut down immediately.
        withStopException {
            connectionEventGroup.shutdownGracefully(0, 1, TimeUnit.SECONDS).sync()
        }
        withStopException {
            callEventGroup.shutdownGracefully(0, 1, TimeUnit.SECONDS).sync()
        }
    }

    private inline fun <R> withStopException(crossinline block: () -> R) {
        runCatching(block).onFailure {
            environment.log.error("Exception thrown during engine stop", it)
        }
    }

    override fun stop(gracePeriodMillis: Long, timeoutMillis: Long) {
        cancellationJob?.complete()
        monitor.raise(ApplicationStopPreparing, environment)

        val channelsCloseTime = measureTimeMillis {
            val channelFutures = channels?.mapNotNull { if (it.isOpen) it.close() else null }.orEmpty()
            channelFutures.forEach { future ->
                withStopException { future.sync() }
            }
        }

        // Quiet period in Ktor Server and Netty EventLoopGroup are different.
        // Ktor Server waits for all requests to finish without accepting new ones.
        // Netty's EventLoopGroup accepts new tasks during the gracePeriod
        // and always waits at least gracePeriod, even if there are no tasks to complete.
        val noQuietPeriod = 0L

        var remainingTimeoutMillis = (timeoutMillis - channelsCloseTime).coerceAtLeast(100L)

        val connectionsShutdownTime = measureTimeMillis {
            withStopException {
                connectionEventGroup.shutdownGracefully(
                    noQuietPeriod,
                    remainingTimeoutMillis,
                    TimeUnit.MILLISECONDS
                ).sync()
            }
        }

        remainingTimeoutMillis = (remainingTimeoutMillis - connectionsShutdownTime).coerceAtLeast(100L)

        val workersShutdownTime = measureTimeMillis {
            withStopException {
                workerEventGroup.shutdownGracefully(
                    gracePeriodMillis.coerceAtMost(remainingTimeoutMillis),
                    remainingTimeoutMillis,
                    TimeUnit.MILLISECONDS
                ).sync()
            }
        }

        if (!configuration.shareWorkGroup) {
            withStopException {
                // There should be no new tasks to be scheduled at this point; no quiet period is needed.
                remainingTimeoutMillis = (remainingTimeoutMillis - workersShutdownTime).coerceAtLeast(100L)
                callEventGroup.shutdownGracefully(noQuietPeriod, remainingTimeoutMillis, TimeUnit.MILLISECONDS).sync()
            }
        }
    }

    override fun toString(): String {
        return "Netty($environment)"
    }
}

internal fun getChannelClass(): KClass<out ServerSocketChannel> = when {
    KQueue.isAvailable() -> KQueueServerSocketChannel::class
    Epoll.isAvailable() -> EpollServerSocketChannel::class
    else -> NioServerSocketChannel::class
}
