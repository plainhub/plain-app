/*
 * Copyright 2014-2021 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

/**
 * Vendored from io.ktor:ktor-server-core:3.5.2.
 */

package com.ismartcoding.plain.lib.ktorserver.core.http.content

import com.sun.nio.file.SensitivityWatchEventModifier
import io.ktor.http.*
import io.ktor.http.content.*
import com.ismartcoding.plain.lib.ktorserver.core.application.*
import com.ismartcoding.plain.lib.ktorserver.core.application.hooks.*
import com.ismartcoding.plain.lib.ktorserver.core.http.content.FileSystemPaths.Companion.paths
import com.ismartcoding.plain.lib.ktorserver.core.response.*
import com.ismartcoding.plain.lib.ktorserver.core.routing.*
import io.ktor.util.*
import io.ktor.util.date.*
import java.io.File
import java.net.URL
import java.nio.file.FileSystem
import java.nio.file.FileSystems
import java.nio.file.Path
import java.nio.file.StandardWatchEventKinds
import kotlin.io.path.isDirectory
import kotlin.io.path.pathString

/**
 * Attribute that stores the path of the static content being served.
 *
 * It is set by static content handlers (for example, [staticFiles], [staticResources], or the Webjars plugin)
 * when a static file or resource is handled. The value is typically the resolved file path or the requested
 * relative resource path.
 *
 * This attribute is not set in early pipeline phases such as [ApplicationCallPipeline.Setup].
 * For [staticFiles] and [staticResources], it is set during the [ApplicationCallPipeline.Call] phase when routing
 * handles the request.
 *
 */
public val StaticFileLocationProperty: AttributeKey<String> = AttributeKey("StaticFileLocation")

private const val pathParameterName = "static-content-path-parameter"

private val staticRootFolderKey = AttributeKey<File>("BaseFolder")

private val StaticContentAutoHead = createRouteScopedPlugin("StaticContentAutoHead") {

    class HeadResponse(val original: OutgoingContent) : OutgoingContent.NoContent() {
        override val status: HttpStatusCode? get() = original.status
        override val contentType: ContentType? get() = original.contentType
        override val contentLength: Long? get() = original.contentLength
        override fun <T : Any> getProperty(key: AttributeKey<T>) = original.getProperty(key)
        override fun <T : Any> setProperty(key: AttributeKey<T>, value: T?) = original.setProperty(key, value)
        override val headers get() = original.headers
    }

    on(ResponseBodyReadyForSend) { call, content ->
        check(call.request.local.method == HttpMethod.Head)
        if (content is OutgoingContent.ReadChannelContent) content.readFrom().cancel(null)
        transformBodyTo(HeadResponse(content))
    }
}

/**
 * A config for serving static content
 *
 */
public class StaticContentConfig<Resource : Any> internal constructor() {

    private val defaultContentType: (Resource) -> ContentType = {
        when (it) {
            is File -> ContentType.defaultForFile(it)

            is URL -> ContentType.defaultForFilePath(it.path)

            is Path -> ContentType.defaultForPath(it)

            else ->
                throw IllegalArgumentException("Argument can be only of type File, Path or URL, but was ${it::class}")
        }
    }
    internal var contentType: (Resource) -> ContentType = defaultContentType
    internal var cacheControl: (Resource) -> List<CacheControl> = { emptyList() }
    internal var modifier: suspend (Resource, ApplicationCall) -> Unit = { _, _ -> }
    internal var exclude: (Resource) -> Boolean = { false }
    internal var extensions: List<String> = emptyList()
    internal var defaultPath: String? = null
    internal var fallback: suspend (String, ApplicationCall) -> Unit = { _, _ -> }
    internal var preCompressedFileTypes: List<CompressedFileType> = emptyList()
    internal var autoHeadResponse: Boolean = false
    internal var lastModifiedExtractor: (Resource) -> GMTDate? = { null }
    internal var etagExtractor: ETagProvider = ETagProvider { null }

    /**
     * Enables pre-compressed files or resources.
     *
     * For example, for static files, by setting `preCompressed(CompressedFileType.BROTLI)`, the local file
     * /foo/bar.js.br can be found at "/foo/bar.js"
     *
     * Sets appropriate headers and suppresses compression if a pre-compressed file is found.
     *
     * The order in types is *important*.
     * It will determine the priority of serving one versus serving another.
     *
     */
    public fun preCompressed(vararg types: CompressedFileType) {
        preCompressedFileTypes = types.toList()
    }

    /**
     * Enables automatic response to a `HEAD` request for every file/resource that has a `GET` defined.
     *
     */
    public fun enableAutoHeadResponse() {
        autoHeadResponse = true
    }

    /**
     * Configures default [Resource] to respond with when a requested file is not found.
     *
     */
    public fun default(path: String?) {
        this.defaultPath = path
    }

    /**
     * Configures custom fallback behavior when a requested static resource is not found.
     *
     * This function allows you to provide a callback that inspects the originally requested path (e.g. "plugins/file.php")
     * and the [ApplicationCall], and then perform custom logic such as:
     * - Redirecting to a different path,
     * - Responding with a specific HTTP status (e.g., 410 Gone or 400 Bad Request),
     * - Or serving an alternative static file manually.
     *
     * Example:
     * ```
     * staticFiles("/static", File("files")) {
     *   fallback { requestedPath, call ->
     *     when {
     *       requestedPath.endsWith(".php") -> call.respondRedirect("/static/index.html")
     *       requestedPath.endsWith(".xml") -> call.respond(HttpStatusCode.Gone)
     *       else -> call.respondFile(File("files/index.html"))
     *     }
     *   }
     * }
     * ```
     *
     * This differs from the existing `default(path: String?)`:
     * - `default(...)` serves a fixed, path‑agnostic fallback resource.
     * - `fallback { requestedPath, call -> ... }` gives full control and context for conditional behavior.
     * @see default
     *
     */
    public fun fallback(fallback: suspend (String, ApplicationCall) -> Unit) {
        this.fallback = fallback
    }

    /**
     * Configures [ContentType] for requested static content.
     * If the [block] returns `null`, default behavior of guessing [ContentType] from the header will be used.
     * For files, [Resource] is a requested [File].
     * For resources, [Resource] is a [URL] to a requested resource.
     *
     */
    public fun contentType(block: (Resource) -> ContentType?) {
        contentType = { resource -> block(resource) ?: defaultContentType(resource) }
    }

    /**
     * Configures [CacheControl] for requested static content.
     * For files, [Resource] is a requested [File].
     * For resources, [Resource] is a [URL] to a requested resource.
     *
     */
    public fun cacheControl(block: (Resource) -> List<CacheControl>) {
        cacheControl = block
    }

    /**
     * Configures modification of a call for requested content.
     * Useful to add headers to the response, such as [HttpHeaders.ETag]
     * For files, [Resource] is a requested [File].
     * For resources, [Resource] is a [URL] to a requested resource.
     *
     */
    public fun modify(block: suspend (Resource, ApplicationCall) -> Unit) {
        modifier = block
    }

    /**
     * Configures [HttpHeaders.LastModified] for requested static content.
     * For files, [Resource] is a requested [File].
     * For resources, [Resource] is a [URL] to a requested resource.
     *
     * Note: for this functionality to work, you need to install the [ConditionalHeaders] plugin.
     *
     */
    public fun lastModified(block: (Resource) -> GMTDate?) {
        lastModifiedExtractor = block
    }

    /**
     * Configures [HttpHeaders.ETag] for requested content.
     * For files, [Resource] is a requested [File].
     * For resources, [Resource] is a [URL] to a requested resource.
     *
     * Note: for this functionality to work, you need to install the [ConditionalHeaders] plugin.
     *
     */
    public fun etag(block: ETagProvider) {
        etagExtractor = block
    }

    /**
     * Configures resources that should not be served.
     * If this block returns `true` for [Resource], [Application] will respond with [HttpStatusCode.Forbidden].
     * Can be invoked multiple times.
     * For files, [Resource] is a requested [File].
     * For resources, [Resource] is a [URL] to a requested resource.
     *
     */
    public fun exclude(block: (Resource) -> Boolean) {
        val oldBlock = exclude
        exclude = {
            if (oldBlock(it)) {
                true
            } else {
                block(it)
            }
        }
    }

    /**
     * Configures file extension fallbacks.
     * When set, if a file is not found, the search will repeat with the given extensions added to the file name.
     * The first match will be served.
     *
     */
    public fun extensions(vararg extensions: String) {
        this.extensions = extensions.toList()
    }
}

/**
 * Sets up [RoutingRoot] to serve static files.
 * All files inside [dir] will be accessible recursively at "[remotePath]/path/to/file".
 * If the requested file is a directory and [index] is not `null`,
 * then response will be [index] file in the requested directory.
 *
 * If the requested file doesn't exist, or it is a directory and no [index] specified, response will be 404 Not Found.
 *
 * You can use [block] for additional setup.
 *
 */
public fun Route.staticFiles(
    remotePath: String,
    dir: File,
    index: String? = "index.html",
    block: StaticContentConfig<File>.() -> Unit = {}
): Route {
    val staticRoute = StaticContentConfig<File>().apply(block)
    val autoHead = staticRoute.autoHeadResponse
    val compressedTypes = staticRoute.preCompressedFileTypes
    val contentType = staticRoute.contentType
    val cacheControl = staticRoute.cacheControl
    val extensions = staticRoute.extensions
    val modify = staticRoute.modifier
    val exclude = staticRoute.exclude
    val defaultPath = staticRoute.defaultPath
    val fallback = staticRoute.fallback
    val lastModified = staticRoute.lastModifiedExtractor
    val etag = staticRoute.etagExtractor
    return staticContentRoute(remotePath, autoHead) {
        respondStaticFile(
            index = index,
            dir = dir,
            compressedTypes = compressedTypes,
            contentType = contentType,
            cacheControl = cacheControl,
            lastModified = lastModified,
            etag = etag,
            modify = modify,
            exclude = exclude,
            extensions = extensions,
            defaultPath = defaultPath,
            fallback = fallback,
        )
    }
}

/**
 * Sets up [RoutingRoot] to serve resources as static content.
 * All resources inside [basePackage] will be accessible recursively at "[remotePath]/path/to/resource".
 * If requested resource doesn't exist and [index] is not `null`,
 * then response will be [index] resource in the requested package.
 *
 * If requested resource doesn't exist and no [index] specified, response will be 404 Not Found.
 *
 * You can use [block] for additional setup.
 *
 */
public fun Route.staticResources(
    remotePath: String,
    basePackage: String?,
    index: String? = "index.html",
    block: StaticContentConfig<URL>.() -> Unit = {}
): Route {
    val staticRoute = StaticContentConfig<URL>().apply(block)
    val autoHead = staticRoute.autoHeadResponse
    val compressedTypes = staticRoute.preCompressedFileTypes
    val contentType = staticRoute.contentType
    val cacheControl = staticRoute.cacheControl
    val extensions = staticRoute.extensions
    val modifier = staticRoute.modifier
    val exclude = staticRoute.exclude
    val defaultPath = staticRoute.defaultPath
    val fallback = staticRoute.fallback
    val lastModified = staticRoute.lastModifiedExtractor
    val etag = staticRoute.etagExtractor
    return staticContentRoute(remotePath, autoHead) {
        respondStaticResource(
            index = index,
            basePackage = basePackage,
            compressedTypes = compressedTypes,
            contentType = contentType,
            cacheControl = cacheControl,
            lastModified = lastModified,
            etag = etag,
            modifier = modifier,
            exclude = exclude,
            extensions = extensions,
            defaultPath = defaultPath,
            fallback = fallback,
        )
    }
}

/**
 * Sets up [RoutingRoot] to serve contents of [zip] as static content.
 * All paths inside [basePath] will be accessible recursively at "[remotePath]/path/to/resource".
 * If a requested path doesn't exist and [index] is not `null`,
 * then response will be [index] path in the requested package.
 *
 * If a requested path doesn't exist and no [index] specified, response will be 404 Not Found.
 *
 * You can use [block] for additional setup.
 *
 */
public fun Route.staticZip(
    remotePath: String,
    basePath: String?,
    zip: Path,
    index: String? = "index.html",
    block: StaticContentConfig<Path>.() -> Unit = {}
): Route = staticFileSystem(
    remotePath = remotePath,
    basePath = basePath,
    index = index,
    fileSystem = ReloadingZipFileSystem(
        zip,
        environment.classLoader,
        getFileSystem(zip, environment.classLoader).paths()
    ),
    block = block
)

private fun getFileSystem(zip: Path, classLoader: ClassLoader): FileSystem = FileSystems.newFileSystem(zip, classLoader)

/**
 * Allows serving reloading [FileSystem]. Returns [FileSystemPaths],
 * which will be recreated on each request if there were any file changes.
 */
private class ReloadingZipFileSystem(
    private val zip: Path,
    private val classLoader: ClassLoader,
    private var delegate: FileSystemPaths
) : FileSystemPaths {
    private val watchService = FileSystems.getDefault().newWatchService()

    init {
        zip.parent.register(
            watchService,
            arrayOf(
                StandardWatchEventKinds.ENTRY_CREATE,
                StandardWatchEventKinds.ENTRY_DELETE,
                StandardWatchEventKinds.ENTRY_MODIFY,
                StandardWatchEventKinds.OVERFLOW
            ),
            SensitivityWatchEventModifier.HIGH
        )
    }

    override fun getPath(first: String, vararg more: String): Path {
        val key = watchService.poll() ?: return delegate.getPath(first, *more)

        val events = key.pollEvents()
        if (events.isNotEmpty()) {
            delegate = getFileSystem(zip, classLoader).paths()
        }
        key.reset()

        return delegate.getPath(first, *more)
    }
}

/**
 * Sets up [RoutingRoot] to serve [fileSystem] as static content.
 * All paths inside [basePath] will be accessible recursively at "[remotePath]/path/to/resource".
 * If a requested path doesn't exist and [index] is not `null`,
 * then response will be [index] path in the requested package.
 *
 * If a requested path doesn't exist and no [index] specified, response will be 404 Not Found.
 *
 * You can use [block] for additional setup.
 *
 */
public fun Route.staticFileSystem(
    remotePath: String,
    basePath: String?,
    index: String? = "index.html",
    fileSystem: FileSystemPaths = FileSystems.getDefault().paths(),
    block: StaticContentConfig<Path>.() -> Unit = {}
): Route {
    val staticRoute = StaticContentConfig<Path>().apply(block)
    val autoHead = staticRoute.autoHeadResponse
    val compressedTypes = staticRoute.preCompressedFileTypes
    val contentType = staticRoute.contentType
    val cacheControl = staticRoute.cacheControl
    val extensions = staticRoute.extensions
    val modify = staticRoute.modifier
    val exclude = staticRoute.exclude
    val defaultPath = staticRoute.defaultPath
    val fallback = staticRoute.fallback
    val lastModified = staticRoute.lastModifiedExtractor
    val etag = staticRoute.etagExtractor
    return staticContentRoute(remotePath, autoHead) {
        respondStaticPath(
            fileSystem = fileSystem,
            index = index,
            basePath = basePath,
            compressedTypes = compressedTypes,
            contentType = contentType,
            cacheControl = cacheControl,
            lastModified = lastModified,
            etag = etag,
            modify = modify,
            exclude = exclude,
            extensions = extensions,
            defaultPath = defaultPath,
            fallback = fallback,
        )
    }
}

/**
 * Support pre-compressed files and resources
 *
 * For example, by using [preCompressed()] (or [preCompressed(CompressedFileType.BROTLI)]), the local file
 * /foo/bar.js.br can be found @ http.../foo/bar.js
 *
 * Sets appropriate headers and suppresses compression if a pre-compressed file is found
 *
 * Notes:
 *
 * * The order in types is *important*. It will determine the priority of serving one versus serving another
 *
 * * This can't be disabled in a child route if it was enabled in the root route
 *
 */
public fun Route.preCompressed(
    vararg types: CompressedFileType = CompressedFileType.entries.toTypedArray(),
    configure: Route.() -> Unit
) {
    val existing = staticContentEncodedTypes ?: emptyList()
    val mixedTypes = (existing + types.asList()).distinct()
    attributes.put(compressedKey, mixedTypes)
    configure()
    attributes.remove(compressedKey)
}

/**
 * Base folder for relative files calculations for static content
 *
 */
@Deprecated(
    "This property only used in deprecated functions `files`, `file` and `default`. " +
        "Please use `staticFiles` or `staticResources` instead"
)
@Suppress("DEPRECATION")
public var Route.staticRootFolder: File?
    get() = attributes.getOrNull(staticRootFolderKey) ?: parent?.staticRootFolder
    set(value) {
        if (value != null) {
            attributes.put(staticRootFolderKey, value)
        } else {
            attributes.remove(staticRootFolderKey)
        }
    }

private fun File?.combine(file: File) = when {
    this == null -> file
    else -> resolve(file)
}

/**
 * Create a block for static content
 *
 */
@Deprecated("Please use `staticFiles` or `staticResources` instead")
public fun Route.static(configure: Route.() -> Unit): Route = apply(configure)

/**
 * Create a block for static content at specified [remotePath]
 *
 */
@Deprecated("Please use `staticFiles` or `staticResources` instead")
public fun Route.static(remotePath: String, configure: Route.() -> Unit): Route =
    route(remotePath, configure)

/**
 * Specifies [localPath] as a default file to serve when folder is requested
 *
 */

@Deprecated("Please use `staticFiles` instead")
@Suppress("DEPRECATION")
public fun Route.default(localPath: String): Unit = default(File(localPath))

/**
 * Specifies [localPath] as a default file to serve when folder is requested
 *
 */
@Deprecated("Please use `staticFiles` instead")
@Suppress("DEPRECATION")
public fun Route.default(localPath: File) {
    val file = staticRootFolder.combine(localPath)
    val compressedTypes = staticContentEncodedTypes
    get {
        call.respondStaticFile(file, compressedTypes)
    }
}

/**
 * Sets up routing to serve [localPath] file as [remotePath]
 *
 */

@Deprecated("Please use `staticFiles` instead")
@Suppress("DEPRECATION")
public fun Route.file(remotePath: String, localPath: String = remotePath): Unit =
    file(remotePath, File(localPath))

/**
 * Sets up routing to serve [localPath] file as [remotePath]
 *
 */
@Deprecated("Please use `staticFiles` instead")
@Suppress("DEPRECATION")
public fun Route.file(remotePath: String, localPath: File) {
    val file = staticRootFolder.combine(localPath)
    val compressedTypes = staticContentEncodedTypes
    get(remotePath) {
        call.respondStaticFile(file, compressedTypes)
    }
}

/**
 * Sets up routing to serve all files from [folder]
 *
 */

@Deprecated("Please use `staticFiles` instead")
@Suppress("DEPRECATION")
public fun Route.files(folder: String): Unit = files(File(folder))

/**
 * Sets up routing to serve all files from [folder]
 *
 */
@Deprecated("Please use `staticFiles` instead")
@Suppress("DEPRECATION")
public fun Route.files(folder: File) {
    val dir = staticRootFolder.combine(folder)
    val compressedTypes = staticContentEncodedTypes
    get("{$pathParameterName...}") {
        val relativePath = call.parameters.getAll(pathParameterName)?.joinToString(File.separator) ?: return@get
        val file = dir.combineSafe(relativePath)
        call.respondStaticFile(file, compressedTypes)
    }
}

private val staticBasePackageName = AttributeKey<String>("BasePackage")

/**
 * Base package for relative resources calculations for static content
 *
 */

@Deprecated("Please use `staticResources` instead")
@Suppress("DEPRECATION")
public var Route.staticBasePackage: String?
    get() = attributes.getOrNull(staticBasePackageName) ?: parent?.staticBasePackage
    set(value) {
        if (value != null) {
            attributes.put(staticBasePackageName, value)
        } else {
            attributes.remove(staticBasePackageName)
        }
    }

private fun String?.combinePackage(resourcePackage: String?) = when {
    this == null -> resourcePackage
    resourcePackage == null -> this
    else -> "$this.$resourcePackage"
}

/**
 * Sets up routing to serve [resource] as [remotePath] in [resourcePackage]
 *
 */

@Deprecated("Please use `staticResources` instead")
@Suppress("DEPRECATION")
public fun Route.resource(remotePath: String, resource: String = remotePath, resourcePackage: String? = null) {
    val compressedTypes = staticContentEncodedTypes
    val packageName = staticBasePackage.combinePackage(resourcePackage)
    get(remotePath) {
        call.respondStaticResource(
            requestedResource = resource,
            packageName = packageName,
            compressedTypes = compressedTypes
        )
    }
}

/**
 * Sets up routing to serve all resources in [resourcePackage]
 *
 */

@Deprecated("Please use `staticResources` instead")
@Suppress("DEPRECATION")
public fun Route.resources(resourcePackage: String? = null) {
    val packageName = staticBasePackage.combinePackage(resourcePackage)
    val compressedTypes = staticContentEncodedTypes
    get("{$pathParameterName...}") {
        val relativePath = call.parameters.getAll(pathParameterName)?.joinToString(File.separator) ?: return@get
        call.respondStaticResource(
            requestedResource = relativePath,
            packageName = packageName,
            compressedTypes = compressedTypes
        )
    }
}

/**
 * Specifies [resource] as a default resources to serve when folder is requested
 *
 */

@Deprecated("Please use `staticResources` instead")
@Suppress("DEPRECATION")
public fun Route.defaultResource(resource: String, resourcePackage: String? = null) {
    val packageName = staticBasePackage.combinePackage(resourcePackage)
    val compressedTypes = staticContentEncodedTypes
    get {
        call.respondStaticResource(
            requestedResource = resource,
            packageName = packageName,
            compressedTypes = compressedTypes
        )
    }
}

/**
 * Returns `true` if static content is being served for this call.
 *
 * This function returns `false` in early pipeline phases such as [ApplicationCallPipeline.Setup],
 * because static content routing runs later during [ApplicationCallPipeline.Call].
 * For example, it cannot be used inside the CallId plugin `retrieve` block.
 *
 * Use this function in response hooks such as [PluginBuilder.onCallRespond]
 * or [ResponseSent] to detect calls that serve static content.
 *
 */
public fun ApplicationCall.isStaticContent(): Boolean = attributes.contains(StaticFileLocationProperty)

private fun Route.staticContentRoute(
    remotePath: String,
    autoHead: Boolean,
    handler: suspend (ApplicationCall).() -> Unit
) = createChild(TailcardSelector).apply {
    route(remotePath) {
        route("{$pathParameterName...}") {
            get {
                call.handler()
            }
            if (autoHead) {
                method(HttpMethod.Head) {
                    install(StaticContentAutoHead)
                    handle {
                        call.handler()
                    }
                }
            }
        }
    }
}

private suspend fun ApplicationCall.respondStaticFile(
    index: String?,
    dir: File,
    compressedTypes: List<CompressedFileType>?,
    contentType: (File) -> ContentType,
    cacheControl: (File) -> List<CacheControl>,
    lastModified: (File) -> GMTDate?,
    etag: ETagProvider,
    modify: suspend (File, ApplicationCall) -> Unit,
    exclude: (File) -> Boolean,
    extensions: List<String>,
    defaultPath: String?,
    fallback: suspend (String, ApplicationCall) -> Unit,
) {
    val relativePath = parameters.getAll(pathParameterName)?.joinToString(File.separator) ?: return
    val requestedFile = dir.combineSafe(relativePath)

    suspend fun checkExclude(file: File): Boolean {
        if (!exclude(file)) return false
        respond(HttpStatusCode.Forbidden)
        return true
    }

    val isDirectory = requestedFile.isDirectory
    if (index != null && isDirectory) {
        respondStaticFile(
            File(requestedFile, index),
            compressedTypes,
            contentType,
            cacheControl,
            lastModified,
            etag,
            modify
        )
    } else if (!isDirectory) {
        if (checkExclude(requestedFile)) return

        respondStaticFile(requestedFile, compressedTypes, contentType, cacheControl, lastModified, etag, modify)
        if (isHandled) return
        for (extension in extensions) {
            val fileWithExtension = File("${requestedFile.path}.$extension")
            if (checkExclude(fileWithExtension)) return
            respondStaticFile(fileWithExtension, compressedTypes, contentType, cacheControl, lastModified, etag, modify)
            if (isHandled) return
        }
    }

    if (isHandled) return
    if (defaultPath != null) {
        respondStaticFile(
            File(dir, defaultPath),
            compressedTypes,
            contentType,
            cacheControl,
            lastModified,
            etag,
            modify
        )
    }

    if (isHandled) return
    fallback(relativePath, this)
}

private suspend fun ApplicationCall.respondStaticPath(
    fileSystem: FileSystemPaths,
    index: String?,
    basePath: String?,
    compressedTypes: List<CompressedFileType>?,
    contentType: (Path) -> ContentType,
    cacheControl: (Path) -> List<CacheControl>,
    lastModified: (Path) -> GMTDate?,
    etag: ETagProvider,
    modify: suspend (Path, ApplicationCall) -> Unit,
    exclude: (Path) -> Boolean,
    extensions: List<String>,
    defaultPath: String?,
    fallback: suspend (String, ApplicationCall) -> Unit,
) {
    val relativePath = parameters.getAll(pathParameterName)?.joinToString(File.separator) ?: return
    val requestedPath = fileSystem.getPath(basePath.orEmpty()).combineSafe(fileSystem.getPath(relativePath))

    suspend fun checkExclude(path: Path): Boolean {
        if (!exclude(path)) return false
        respond(HttpStatusCode.Forbidden)
        return true
    }

    val isDirectory = requestedPath.isDirectory()
    if (index != null && isDirectory) {
        respondStaticPath(
            fileSystem,
            requestedPath.resolve(index),
            compressedTypes,
            contentType,
            cacheControl,
            modify,
            lastModified,
            etag
        )
    } else if (!isDirectory) {
        if (checkExclude(requestedPath)) return

        respondStaticPath(
            fileSystem,
            requestedPath,
            compressedTypes,
            contentType,
            cacheControl,
            modify,
            lastModified,
            etag
        )
        if (isHandled) return
        for (extension in extensions) {
            val pathWithExtension = fileSystem.getPath("${requestedPath.pathString}.$extension")
            if (checkExclude(pathWithExtension)) return
            respondStaticPath(
                fileSystem,
                pathWithExtension,
                compressedTypes,
                contentType,
                cacheControl,
                modify,
                lastModified,
                etag
            )
            if (isHandled) return
        }
    }

    if (isHandled) return
    if (defaultPath != null) {
        respondStaticPath(
            fileSystem,
            fileSystem.getPath(basePath ?: "", defaultPath),
            compressedTypes,
            contentType,
            cacheControl,
            modify,
            lastModified,
            etag
        )
    }

    if (isHandled) return
    fallback(relativePath, this)
}

private suspend fun ApplicationCall.respondStaticResource(
    index: String?,
    basePackage: String?,
    compressedTypes: List<CompressedFileType>?,
    contentType: (URL) -> ContentType,
    cacheControl: (URL) -> List<CacheControl>,
    lastModified: (URL) -> GMTDate?,
    etag: ETagProvider,
    modifier: suspend (URL, ApplicationCall) -> Unit,
    exclude: (URL) -> Boolean,
    extensions: List<String>,
    defaultPath: String?,
    fallback: suspend (String, ApplicationCall) -> Unit,
) {
    val relativePath = parameters.getAll(pathParameterName)?.joinToString(File.separator) ?: return

    respondStaticResource(
        requestedResource = relativePath,
        packageName = basePackage,
        compressedTypes = compressedTypes,
        contentType = contentType,
        cacheControl = cacheControl,
        modifier = modifier,
        lastModified = lastModified,
        etag = etag,
        exclude = exclude
    )

    if (isHandled) return
    for (extension in extensions) {
        respondStaticResource(
            requestedResource = "$relativePath.$extension",
            packageName = basePackage,
            compressedTypes = compressedTypes,
            contentType = contentType,
            cacheControl = cacheControl,
            modifier = modifier,
            lastModified = lastModified,
            etag = etag,
            exclude = exclude
        )
        if (isHandled) return
    }

    if (index != null) {
        respondStaticResource(
            requestedResource = "$relativePath${File.separator}$index",
            packageName = basePackage,
            compressedTypes = compressedTypes,
            contentType = contentType,
            cacheControl = cacheControl,
            modifier = modifier,
            lastModified = lastModified,
            etag = etag,
        )
    }

    if (isHandled) return
    if (defaultPath != null) {
        respondStaticResource(
            requestedResource = defaultPath,
            packageName = basePackage,
            compressedTypes = compressedTypes,
            contentType = contentType,
            cacheControl = cacheControl,
            modifier = modifier,
            lastModified = lastModified,
            etag = etag,
        )
    }

    if (isHandled) return
    fallback(relativePath, this)
}

/**
 * Wrapper on [FileSystem] for more specific delegation since we use only [getPath] method from it.
 *
 */
public interface FileSystemPaths {
    public companion object {
        /**
         * Creates a [FileSystemPaths] instance from a [FileSystem].
         *
         */
        public fun FileSystem.paths(): FileSystemPaths = object : FileSystemPaths {
            override fun getPath(first: String, vararg more: String): Path = this@paths.getPath(first, *more)
        }
    }

    /**
     * Converts a path string, or a sequence of strings that when joined form a path string, to a Path.
     * Equal to [FileSystem.getPath].
     *
     */
    public fun getPath(first: String, vararg more: String): Path
}

// Adds lower priority to the route so that it can be used as a fallback
private object TailcardSelector : RouteSelector() {
    override suspend fun evaluate(context: RoutingResolveContext, segmentIndex: Int): RouteSelectorEvaluation =
        RouteSelectorEvaluation.Success(quality = RouteSelectorEvaluation.qualityTailcard)

    override fun toString(): String = "(static-content)"
}
