/*
 * Copyright 2014-2021 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

/**
 * Vendored from io.ktor:ktor-server-core:3.5.2.
 */

package com.ismartcoding.plain.lib.ktorserver.core.http.content

import io.ktor.http.*
import io.ktor.http.content.*
import com.ismartcoding.plain.lib.ktorserver.core.application.*
import com.ismartcoding.plain.lib.ktorserver.core.plugins.*
import com.ismartcoding.plain.lib.ktorserver.core.util.*
import io.ktor.utils.io.*
import java.io.File
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 *
 *
 * @param path is a relative path to the resource
 * @param resourcePackage is a base package the path to be appended to
 * @param mimeResolve is a function that resolves content type by file extension, optional
 *
 * @return [LocalFileContent] or [JarFileContent] or `null`
 */
@OptIn(InternalAPI::class)
public fun ApplicationCall.resolveResource(
    path: String,
    resourcePackage: String? = null,
    classLoader: ClassLoader = application.environment.classLoader,
    mimeResolve: (String) -> ContentType = { ContentType.defaultForFileExtension(it) }
): OutgoingContent.ReadChannelContent? {
    if (path.endsWith("/") || path.endsWith("\\")) {
        return null
    }

    val normalizedPath = normalisedPath(resourcePackage, path)

    for (url in classLoader.getResources(normalizedPath).asSequence()) {
        resourceClasspathResource(url, normalizedPath) { mimeResolve(it.path.extension()) }?.let { content ->
            return content
        }
    }

    return null
}

private val resourceCache by lazy { ConcurrentHashMap<String, URL>() }

@OptIn(InternalAPI::class)
internal fun Application.resolveResource(
    path: String,
    resourcePackage: String? = null,
    classLoader: ClassLoader = environment.classLoader,
    mimeResolve: (URL) -> ContentType
): Pair<URL, OutgoingContent.ReadChannelContent>? {
    if (path.endsWith("/") || path.endsWith("\\")) {
        return null
    }

    val normalizedPath = normalisedPath(resourcePackage, path)
    val cacheKey = "${classLoader.hashCode()}/$normalizedPath"
    val resolveContent: (URL) -> Pair<URL, OutgoingContent.ReadChannelContent>? = { url ->
        resourceClasspathResource(url, normalizedPath, mimeResolve)?.let { url to it }
    }
    return resourceCache[cacheKey]?.let(resolveContent)
        ?: classLoader.getResources(normalizedPath).asSequence()
            .firstNotNullOfOrNull(resolveContent)?.also { (url) ->
                resourceCache[cacheKey] = url
            }
}

/**
 * Attempt to find a local file or a file inside of zip. This is not required but very good to have
 * to improve performance and unnecessary [java.io.InputStream] creation.
 *
 */
@InternalAPI
public fun resourceClasspathResource(
    url: URL,
    path: String,
    mimeResolve: (URL) -> ContentType
): OutgoingContent.ReadChannelContent? {
    return when (url.protocol) {
        "file" -> {
            val file = File(url.path.decodeURLPart())
            if (file.isFile) LocalFileContent(file, mimeResolve(url)) else null
        }

        "jar" -> {
            if (path.endsWith("/")) {
                null
            } else {
                val zipFile = findContainingJarFile(url.toString())
                if (zipFile == null) {
                    return URIFileContent(url, mimeResolve(url))
                }
                JarFileContent(zipFile, path, mimeResolve(url)).takeIf { it.isFile }
            }
        }

        "jrt", "resource" -> {
            URIFileContent(url, mimeResolve(url))
        }

        else -> null
    }
}

/**
 * Returns the local jar file containing the resource pointed to by the given URL,
 * or `null` if URL is not a standard JAR URL.
 *
 * The syntax of a JAR URL is: `jar:<url>!/{entry}`
 * Example: `jar:file:/path/to/app.jar!/entry/inside/jar`
 *
 * Examples:
 * - `jar:file:/dist/app.jar!/static/index.html`              → returns `/dist/app.jar`
 * - `jar:file:/dist/app.jar!`                                → returns `/dist/app.jar`
 * - `jar:file:/outer.jar!/lib/dep.jar!/x.css`                → throws IllegalArgumentException (nested)
 * - `jar:nested:/path/to/app.jar/!BOOT-INF/classes/!/static` → returns `null` (non-local container)
 */
internal fun findContainingJarFile(url: String): File? {
    if (!url.startsWith(JAR_PREFIX)) return null

    val jarPathSeparator = url.indexOf("!", startIndex = JAR_PREFIX.length)
    if (jarPathSeparator == -1) {
        return null
    }
    val nextJarSeparator = url.indexOf("!", startIndex = jarPathSeparator + 1)
    if (nextJarSeparator != -1) {
        // KTOR-8883 Support nested jars in static resources
        throw IllegalArgumentException("Only local jars are supported (jar:file:)")
    }

    return File(url.substring(JAR_PREFIX.length, jarPathSeparator).decodeURLPart())
}

internal fun String.extension(): String {
    val indexOfName = lastIndexOf('/').takeIf { it != -1 } ?: lastIndexOf('\\').takeIf { it != -1 } ?: 0
    val indexOfDot = indexOf('.', indexOfName)
    return if (indexOfDot >= 0) substring(indexOfDot) else ""
}

private fun normalisedPath(resourcePackage: String?, path: String): String {
    // note: we don't need to check for ".." in the normalizedPath because all ".." get replaced with //
    val pathComponents = path.split('/', '\\')
    if (pathComponents.contains("..")) {
        throw BadRequestException("Relative path should not contain path traversing characters: $path")
    }
    return (resourcePackage.orEmpty().split('.', '/', '\\') + pathComponents)
        .normalizePathComponents()
        .joinToString("/")
}

private const val JAR_PREFIX = "jar:file:"
