package com.ismartcoding.plain.lib.pinyin

import com.ismartcoding.plain.lib.Emit

/**
 * 正向最大匹配选择器
 */
internal class ForwardLongestSelector : SegmentationSelector {
    override fun select(emits: Collection<Emit>): List<Emit> {
        val results: MutableList<Emit> = ArrayList(emits)
        results.sortWith(HIT_COMPARATOR)
        var endValueToRemove = -1
        val emitToRemove: MutableSet<Emit> = mutableSetOf()
        for (emit in results) {
            if (emit.start > endValueToRemove && emit.end > endValueToRemove) {
                endValueToRemove = emit.end
            } else {
                emitToRemove.add(emit)
            }
        }
        results.removeAll(emitToRemove)
        return results
    }

    companion object {
        val HIT_COMPARATOR = Engine.EmitComparator()
    }
}
