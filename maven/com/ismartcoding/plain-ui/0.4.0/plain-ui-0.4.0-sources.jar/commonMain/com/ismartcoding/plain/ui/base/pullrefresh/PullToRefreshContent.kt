package com.ismartcoding.plain.ui.base.pullrefresh

import com.ismartcoding.plain.ui.resources.Res as UiRes
import com.ismartcoding.plain.ui.resources.loading as ui_string_loading
import com.ismartcoding.plain.ui.resources.srl_header_failed as ui_string_srl_header_failed
import com.ismartcoding.plain.ui.resources.srl_header_finish as ui_string_srl_header_finish
import com.ismartcoding.plain.ui.resources.srl_header_refreshing as ui_string_srl_header_refreshing
import com.ismartcoding.plain.ui.resources.srl_header_pulling as ui_string_srl_header_pulling
import com.ismartcoding.plain.ui.resources.srl_header_release as ui_string_srl_header_release

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import org.jetbrains.compose.resources.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

@Composable
fun RefreshLayoutState.PullToRefreshContent(
    createText: @Composable (RefreshContentState) -> String = {
        when (it) {
            RefreshContentState.Failed -> stringResource(UiRes.string.ui_string_srl_header_failed)
            RefreshContentState.Finished -> stringResource(UiRes.string.ui_string_srl_header_finish)
            RefreshContentState.Refreshing -> stringResource(UiRes.string.ui_string_srl_header_refreshing)
            RefreshContentState.Dragging -> {
                if (abs(getRefreshContentOffset()) < getRefreshContentThreshold()) {
                    stringResource(UiRes.string.ui_string_srl_header_pulling)
                } else {
                    stringResource(UiRes.string.ui_string_srl_header_release)
                }
            }
        }
    }
) {
    val refreshContentState by remember {
        getRefreshContentState()
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Text(
            text = createText(refreshContentState),
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
