package com.ismartcoding.plain.ui.base

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.unit.dp
import com.ismartcoding.plain.enums.ButtonSize
import com.ismartcoding.plain.enums.ButtonType

@Composable
fun POutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: Painter? = null,
    type: ButtonType = ButtonType.PRIMARY,
    buttonSize: ButtonSize = ButtonSize.MEDIUM,
    isLoading: Boolean = false,
    enabled: Boolean = true,
    contentColor: Color? = null,
) {
    val resolvedColor = contentColor ?: when (type) {
        ButtonType.PRIMARY -> MaterialTheme.colorScheme.primary
        ButtonType.TERTIARY -> MaterialTheme.colorScheme.tertiary
        ButtonType.DANGER -> MaterialTheme.colorScheme.error
    }
    val borderColor = resolvedColor.copy(alpha = 0.5f)
    // Disabled follows the Material default graying so icon, text and border
    // mute together instead of a full-color icon beside washed-out text.
    val disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
    val disabledBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)

    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .height(buttonSize.height),
        shape = RoundedCornerShape(buttonSize.cornerRadius),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = resolvedColor,
            disabledContainerColor = Color.Transparent,
            disabledContentColor = disabledContentColor,
        ),
        border = BorderStroke(1.dp, if (enabled) borderColor else disabledBorderColor),
        contentPadding = buttonSize.getPaddingValues(),
        enabled = enabled && !isLoading,
    ) {
        Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(if (buttonSize == ButtonSize.SMALL) 14.dp else 16.dp), strokeWidth = 2.dp, color = resolvedColor)
                HorizontalSpace(8.dp)
            } else if (icon != null) {
                Icon(painter = icon, contentDescription = null, modifier = Modifier.size(if (buttonSize == ButtonSize.SMALL) 16.dp else 20.dp))
                HorizontalSpace(8.dp)
            }
            Text(
                text = text,
                style = buttonSize.textStyle(),
                fontWeight = buttonSize.fontWeight()
            )
        }
    }
} 