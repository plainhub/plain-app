@file:OptIn(InternalResourceApi::class)

package com.ismartcoding.plain.ui.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.RegionQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.ismartcoding.plain.ui.resources/"

@delegate:ResourceContentHash(-158_565_974)
public val Res.string.back: StringResource by lazy {
      StringResource("string:back", "back", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 10, 32),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 10, 24),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 10, 28),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 10, 24),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 10, 28),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 10, 28),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 10, 28),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 10, 20),
      ))
    }

@delegate:ResourceContentHash(-2_010_031_908)
public val Res.string.loading: StringResource by lazy {
      StringResource("string:loading", "loading", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 43, 55),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 35, 27),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 31, 31),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 31, 47),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 39, 63),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 35, 35),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 31, 35),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 31, 35),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 31, 27),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 31, 35),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 39, 43),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 39, 59),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 31, 35),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 39, 35),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 31, 31),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 31, 31),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 31, 31),
      ))
    }

@delegate:ResourceContentHash(84_525_364)
public val Res.string.srl_header_failed: StringResource by lazy {
      StringResource("string:srl_header_failed", "srl_header_failed", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 99, 105),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 63, 65),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 63, 49),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 79, 61),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 103, 117),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 71, 53),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 67, 61),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 67, 53),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 59, 49),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 67, 57),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 83, 81),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 99, 97),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 67, 53),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 75, 57),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 63, 41),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 63, 41),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 63, 45),
      ))
    }

@delegate:ResourceContentHash(2_146_076_225)
public val Res.string.srl_header_finish: StringResource by lazy {
      StringResource("string:srl_header_finish", "srl_header_finish", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 205, 81),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 129, 41),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 113, 41),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 141, 41),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 221, 69),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 125, 41),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 129, 41),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 121, 49),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 109, 37),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 125, 41),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 165, 49),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 197, 117),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 121, 37),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 133, 45),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 105, 41),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 105, 41),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 109, 37),
      ))
    }

@delegate:ResourceContentHash(-154_473_114)
public val Res.string.srl_header_last_refresh_days: StringResource by lazy {
      StringResource("string:srl_header_last_refresh_days", "srl_header_last_refresh_days", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 147, 72),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 147, 72),
      ))
    }

@delegate:ResourceContentHash(-958_313_830)
public val Res.string.srl_header_last_refresh_hours: StringResource by lazy {
      StringResource("string:srl_header_last_refresh_hours", "srl_header_last_refresh_hours", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 220, 77),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 220, 73),
      ))
    }

@delegate:ResourceContentHash(-1_249_116_746)
public val Res.string.srl_header_last_refresh_just_now: StringResource by lazy {
      StringResource("string:srl_header_last_refresh_just_now", "srl_header_last_refresh_just_now", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 298, 68),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 294, 72),
      ))
    }

@delegate:ResourceContentHash(-790_141_994)
public val Res.string.srl_header_last_refresh_minutes: StringResource by lazy {
      StringResource("string:srl_header_last_refresh_minutes", "srl_header_last_refresh_minutes", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 367, 79),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 367, 75),
      ))
    }

@delegate:ResourceContentHash(259_796_772)
public val Res.string.srl_header_pulling: StringResource by lazy {
      StringResource("string:srl_header_pulling", "srl_header_pulling", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 287, 78),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 171, 74),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 155, 74),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 183, 74),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 291, 130),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 167, 74),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 171, 62),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 171, 66),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 147, 66),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 167, 66),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 215, 98),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 315, 130),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 159, 70),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 179, 66),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 447, 50),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 147, 50),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 443, 54),
      ))
    }

@delegate:ResourceContentHash(-902_543_031)
public val Res.string.srl_header_refreshing: StringResource by lazy {
      StringResource("string:srl_header_refreshing", "srl_header_refreshing", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 366, 85),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 246, 49),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 230, 49),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 258, 65),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 422, 105),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 242, 53),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 234, 45),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 238, 57),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 214, 49),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 234, 49),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 314, 61),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 446, 125),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 230, 49),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 246, 57),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 498, 49),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 198, 49),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 498, 49),
      ))
    }

@delegate:ResourceContentHash(1_828_696_498)
public val Res.string.srl_header_release: StringResource by lazy {
      StringResource("string:srl_header_release", "srl_header_release", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 452, 66),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 296, 62),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 280, 54),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 324, 62),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 528, 114),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 296, 58),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 280, 70),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 296, 74),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 264, 62),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 284, 54),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 376, 90),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 572, 122),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 280, 62),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 304, 58),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 548, 50),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 248, 50),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 548, 50),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("back", Res.string.back)
  map.put("loading", Res.string.loading)
  map.put("srl_header_failed", Res.string.srl_header_failed)
  map.put("srl_header_finish", Res.string.srl_header_finish)
  map.put("srl_header_last_refresh_days", Res.string.srl_header_last_refresh_days)
  map.put("srl_header_last_refresh_hours", Res.string.srl_header_last_refresh_hours)
  map.put("srl_header_last_refresh_just_now", Res.string.srl_header_last_refresh_just_now)
  map.put("srl_header_last_refresh_minutes", Res.string.srl_header_last_refresh_minutes)
  map.put("srl_header_pulling", Res.string.srl_header_pulling)
  map.put("srl_header_refreshing", Res.string.srl_header_refreshing)
  map.put("srl_header_release", Res.string.srl_header_release)
}
