package com.ismartcoding.plain.ui.theme

import androidx.compose.ui.unit.dp

object Spacing {
    val xs = 4.dp
    val sm = 8.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
}
