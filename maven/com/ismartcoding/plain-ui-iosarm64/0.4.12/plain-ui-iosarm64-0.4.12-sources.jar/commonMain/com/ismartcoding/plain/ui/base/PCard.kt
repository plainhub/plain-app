package com.ismartcoding.plain.ui.base

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import com.ismartcoding.plain.ui.theme.cardBackgroundNormal

@Composable
fun PCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium),
        colors = CardDefaults.cardColors().copy(
            containerColor = MaterialTheme.colorScheme.cardBackgroundNormal
        )
    ) {
        content()
    }
}
