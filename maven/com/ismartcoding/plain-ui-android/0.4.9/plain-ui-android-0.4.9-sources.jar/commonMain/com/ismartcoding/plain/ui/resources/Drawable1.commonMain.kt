@file:OptIn(InternalResourceApi::class)

package com.ismartcoding.plain.ui.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/com.ismartcoding.plain.ui.resources/"

@delegate:ResourceContentHash(-1_959_867_108)
public val Res.drawable.launcher_background: DrawableResource by lazy {
      DrawableResource("drawable:launcher_background", setOf(
        ResourceItem(setOf(), "${MD}drawable/launcher_background.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_109_355_055)
public val Res.drawable.layers: DrawableResource by lazy {
      DrawableResource("drawable:layers", setOf(
        ResourceItem(setOf(), "${MD}drawable/layers.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_410_318_434)
public val Res.drawable.layout_grid: DrawableResource by lazy {
      DrawableResource("drawable:layout_grid", setOf(
        ResourceItem(setOf(), "${MD}drawable/layout_grid.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(326_744_180)
public val Res.drawable.left_panel_close: DrawableResource by lazy {
      DrawableResource("drawable:left_panel_close", setOf(
        ResourceItem(setOf(), "${MD}drawable/left_panel_close.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_103_795_319)
public val Res.drawable.left_panel_open: DrawableResource by lazy {
      DrawableResource("drawable:left_panel_open", setOf(
        ResourceItem(setOf(), "${MD}drawable/left_panel_open.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-700_051_265)
public val Res.drawable.lightbulb: DrawableResource by lazy {
      DrawableResource("drawable:lightbulb", setOf(
        ResourceItem(setOf(), "${MD}drawable/lightbulb.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(462_197_831)
public val Res.drawable.link: DrawableResource by lazy {
      DrawableResource("drawable:link", setOf(
        ResourceItem(setOf(), "${MD}drawable/link.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(51_550_430)
public val Res.drawable.list_checks: DrawableResource by lazy {
      DrawableResource("drawable:list_checks", setOf(
        ResourceItem(setOf(), "${MD}drawable/list_checks.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-513_352_506)
public val Res.drawable.list_music: DrawableResource by lazy {
      DrawableResource("drawable:list_music", setOf(
        ResourceItem(setOf(), "${MD}drawable/list_music.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_220_771_622)
public val Res.drawable.lock: DrawableResource by lazy {
      DrawableResource("drawable:lock", setOf(
        ResourceItem(setOf(), "${MD}drawable/lock.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_388_236_273)
public val Res.drawable.looks_one: DrawableResource by lazy {
      DrawableResource("drawable:looks_one", setOf(
        ResourceItem(setOf(), "${MD}drawable/looks_one.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_070_890_458)
public val Res.drawable.looks_two: DrawableResource by lazy {
      DrawableResource("drawable:looks_two", setOf(
        ResourceItem(setOf(), "${MD}drawable/looks_two.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(46_357_103)
public val Res.drawable.markdown: DrawableResource by lazy {
      DrawableResource("drawable:markdown", setOf(
        ResourceItem(setOf(), "${MD}drawable/markdown.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_082_525_910)
public val Res.drawable.match_case: DrawableResource by lazy {
      DrawableResource("drawable:match_case", setOf(
        ResourceItem(setOf(), "${MD}drawable/match_case.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(493_319_598)
public val Res.drawable.maximize: DrawableResource by lazy {
      DrawableResource("drawable:maximize", setOf(
        ResourceItem(setOf(), "${MD}drawable/maximize.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_867_991_979)
public val Res.drawable.maximize_2: DrawableResource by lazy {
      DrawableResource("drawable:maximize_2", setOf(
        ResourceItem(setOf(), "${MD}drawable/maximize_2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_899_457_419)
public val Res.drawable.menu: DrawableResource by lazy {
      DrawableResource("drawable:menu", setOf(
        ResourceItem(setOf(), "${MD}drawable/menu.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(617_215_741)
public val Res.drawable.message_circle: DrawableResource by lazy {
      DrawableResource("drawable:message_circle", setOf(
        ResourceItem(setOf(), "${MD}drawable/message_circle.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_493_080_617)
public val Res.drawable.message_square_text: DrawableResource by lazy {
      DrawableResource("drawable:message_square_text", setOf(
        ResourceItem(setOf(), "${MD}drawable/message_square_text.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_014_198_873)
public val Res.drawable.more_horiz: DrawableResource by lazy {
      DrawableResource("drawable:more_horiz", setOf(
        ResourceItem(setOf(), "${MD}drawable/more_horiz.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-809_500_136)
public val Res.drawable.more_three_dots: DrawableResource by lazy {
      DrawableResource("drawable:more_three_dots", setOf(
        ResourceItem(setOf(), "${MD}drawable/more_three_dots.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_029_374_316)
public val Res.drawable.mouse_pointer: DrawableResource by lazy {
      DrawableResource("drawable:mouse_pointer", setOf(
        ResourceItem(setOf(), "${MD}drawable/mouse_pointer.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_086_520_803)
public val Res.drawable.music: DrawableResource by lazy {
      DrawableResource("drawable:music", setOf(
        ResourceItem(setOf(), "${MD}drawable/music.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_345_191_575)
public val Res.drawable.music2: DrawableResource by lazy {
      DrawableResource("drawable:music2", setOf(
        ResourceItem(setOf(), "${MD}drawable/music2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_088_974_570)
public val Res.drawable.notebook_pen: DrawableResource by lazy {
      DrawableResource("drawable:notebook_pen", setOf(
        ResourceItem(setOf(), "${MD}drawable/notebook_pen.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_724_560_769)
public val Res.drawable.octagon_alert: DrawableResource by lazy {
      DrawableResource("drawable:octagon_alert", setOf(
        ResourceItem(setOf(), "${MD}drawable/octagon_alert.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_463_289_315)
public val Res.drawable.package2: DrawableResource by lazy {
      DrawableResource("drawable:package2", setOf(
        ResourceItem(setOf(), "${MD}drawable/package2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_616_235_679)
public val Res.drawable.package_open: DrawableResource by lazy {
      DrawableResource("drawable:package_open", setOf(
        ResourceItem(setOf(), "${MD}drawable/package_open.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_411_581_597)
public val Res.drawable.paint_bucket: DrawableResource by lazy {
      DrawableResource("drawable:paint_bucket", setOf(
        ResourceItem(setOf(), "${MD}drawable/paint_bucket.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_023_278_679)
public val Res.drawable.pause: DrawableResource by lazy {
      DrawableResource("drawable:pause", setOf(
        ResourceItem(setOf(), "${MD}drawable/pause.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_621_230_060)
public val Res.drawable.pen: DrawableResource by lazy {
      DrawableResource("drawable:pen", setOf(
        ResourceItem(setOf(), "${MD}drawable/pen.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-260_202_428)
public val Res.drawable.person: DrawableResource by lazy {
      DrawableResource("drawable:person", setOf(
        ResourceItem(setOf(), "${MD}drawable/person.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_281_670_347)
public val Res.drawable.phone_call: DrawableResource by lazy {
      DrawableResource("drawable:phone_call", setOf(
        ResourceItem(setOf(), "${MD}drawable/phone_call.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_170_018_160)
public val Res.drawable.pip: DrawableResource by lazy {
      DrawableResource("drawable:pip", setOf(
        ResourceItem(setOf(), "${MD}drawable/pip.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(904_704_579)
public val Res.drawable.play_arrow: DrawableResource by lazy {
      DrawableResource("drawable:play_arrow", setOf(
        ResourceItem(setOf(), "${MD}drawable/play_arrow.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(680_859_248)
public val Res.drawable.playlist_add: DrawableResource by lazy {
      DrawableResource("drawable:playlist_add", setOf(
        ResourceItem(setOf(), "${MD}drawable/playlist_add.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-854_551_798)
public val Res.drawable.playlist_check: DrawableResource by lazy {
      DrawableResource("drawable:playlist_check", setOf(
        ResourceItem(setOf(), "${MD}drawable/playlist_check.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-357_568_145)
public val Res.drawable.playlist_remove: DrawableResource by lazy {
      DrawableResource("drawable:playlist_remove", setOf(
        ResourceItem(setOf(), "${MD}drawable/playlist_remove.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_844_086_138)
public val Res.drawable.plus: DrawableResource by lazy {
      DrawableResource("drawable:plus", setOf(
        ResourceItem(setOf(), "${MD}drawable/plus.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-471_687_667)
public val Res.drawable.power_settings: DrawableResource by lazy {
      DrawableResource("drawable:power_settings", setOf(
        ResourceItem(setOf(), "${MD}drawable/power_settings.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_393_661_170)
public val Res.drawable.print: DrawableResource by lazy {
      DrawableResource("drawable:print", setOf(
        ResourceItem(setOf(), "${MD}drawable/print.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-636_263_717)
public val Res.drawable.qr_code: DrawableResource by lazy {
      DrawableResource("drawable:qr_code", setOf(
        ResourceItem(setOf(), "${MD}drawable/qr_code.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-140_532_931)
public val Res.drawable.redo: DrawableResource by lazy {
      DrawableResource("drawable:redo", setOf(
        ResourceItem(setOf(), "${MD}drawable/redo.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(710_665_787)
public val Res.drawable.redo_2: DrawableResource by lazy {
      DrawableResource("drawable:redo_2", setOf(
        ResourceItem(setOf(), "${MD}drawable/redo_2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_001_049_869)
public val Res.drawable.refresh_ccw: DrawableResource by lazy {
      DrawableResource("drawable:refresh_ccw", setOf(
        ResourceItem(setOf(), "${MD}drawable/refresh_ccw.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(997_202_708)
public val Res.drawable.repeat: DrawableResource by lazy {
      DrawableResource("drawable:repeat", setOf(
        ResourceItem(setOf(), "${MD}drawable/repeat.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_106_904_773)
public val Res.drawable.repeat1: DrawableResource by lazy {
      DrawableResource("drawable:repeat1", setOf(
        ResourceItem(setOf(), "${MD}drawable/repeat1.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_859_986_981)
public val Res.drawable.rocket: DrawableResource by lazy {
      DrawableResource("drawable:rocket", setOf(
        ResourceItem(setOf(), "${MD}drawable/rocket.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-895_891_147)
public val Res.drawable.rotate_ccw: DrawableResource by lazy {
      DrawableResource("drawable:rotate_ccw", setOf(
        ResourceItem(setOf(), "${MD}drawable/rotate_ccw.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-222_675_048)
public val Res.drawable.rotate_cw_square: DrawableResource by lazy {
      DrawableResource("drawable:rotate_cw_square", setOf(
        ResourceItem(setOf(), "${MD}drawable/rotate_cw_square.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_223_097_240)
public val Res.drawable.rss: DrawableResource by lazy {
      DrawableResource("drawable:rss", setOf(
        ResourceItem(setOf(), "${MD}drawable/rss.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_176_571_425)
public val Res.drawable.save: DrawableResource by lazy {
      DrawableResource("drawable:save", setOf(
        ResourceItem(setOf(), "${MD}drawable/save.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_981_869_697)
public val Res.drawable.scan_qr_code: DrawableResource by lazy {
      DrawableResource("drawable:scan_qr_code", setOf(
        ResourceItem(setOf(), "${MD}drawable/scan_qr_code.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-130_804_749)
public val Res.drawable.scissors: DrawableResource by lazy {
      DrawableResource("drawable:scissors", setOf(
        ResourceItem(setOf(), "${MD}drawable/scissors.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_658_080_644)
public val Res.drawable.sd_card: DrawableResource by lazy {
      DrawableResource("drawable:sd_card", setOf(
        ResourceItem(setOf(), "${MD}drawable/sd_card.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_607_694_889)
public val Res.drawable.search: DrawableResource by lazy {
      DrawableResource("drawable:search", setOf(
        ResourceItem(setOf(), "${MD}drawable/search.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-534_984_443)
public val Res.drawable.select_all: DrawableResource by lazy {
      DrawableResource("drawable:select_all", setOf(
        ResourceItem(setOf(), "${MD}drawable/select_all.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_054_857_043)
public val Res.drawable.send: DrawableResource by lazy {
      DrawableResource("drawable:send", setOf(
        ResourceItem(setOf(), "${MD}drawable/send.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(536_157_684)
public val Res.drawable.settings: DrawableResource by lazy {
      DrawableResource("drawable:settings", setOf(
        ResourceItem(setOf(), "${MD}drawable/settings.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_451_818_659)
public val Res.drawable.share_2: DrawableResource by lazy {
      DrawableResource("drawable:share_2", setOf(
        ResourceItem(setOf(), "${MD}drawable/share_2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_686_113_463)
public val Res.drawable.shuffle: DrawableResource by lazy {
      DrawableResource("drawable:shuffle", setOf(
        ResourceItem(setOf(), "${MD}drawable/shuffle.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_203_146_360)
public val Res.drawable.skip_next: DrawableResource by lazy {
      DrawableResource("drawable:skip_next", setOf(
        ResourceItem(setOf(), "${MD}drawable/skip_next.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(852_231_787)
public val Res.drawable.skip_previous: DrawableResource by lazy {
      DrawableResource("drawable:skip_previous", setOf(
        ResourceItem(setOf(), "${MD}drawable/skip_previous.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(301_428_490)
public val Res.drawable.smartphone: DrawableResource by lazy {
      DrawableResource("drawable:smartphone", setOf(
        ResourceItem(setOf(), "${MD}drawable/smartphone.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_137_378_799)
public val Res.drawable.sort: DrawableResource by lazy {
      DrawableResource("drawable:sort", setOf(
        ResourceItem(setOf(), "${MD}drawable/sort.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-244_611_237)
public val Res.drawable.square: DrawableResource by lazy {
      DrawableResource("drawable:square", setOf(
        ResourceItem(setOf(), "${MD}drawable/square.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_132_028_292)
public val Res.drawable.square_arrow_out_up_right: DrawableResource by lazy {
      DrawableResource("drawable:square_arrow_out_up_right", setOf(
        ResourceItem(setOf(), "${MD}drawable/square_arrow_out_up_right.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_060_390_425)
public val Res.drawable.square_check: DrawableResource by lazy {
      DrawableResource("drawable:square_check", setOf(
        ResourceItem(setOf(), "${MD}drawable/square_check.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_076_455_655)
public val Res.drawable.square_pen: DrawableResource by lazy {
      DrawableResource("drawable:square_pen", setOf(
        ResourceItem(setOf(), "${MD}drawable/square_pen.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-227_622_573)
public val Res.drawable.sticky_note: DrawableResource by lazy {
      DrawableResource("drawable:sticky_note", setOf(
        ResourceItem(setOf(), "${MD}drawable/sticky_note.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(137_675_254)
public val Res.drawable.strikethrough: DrawableResource by lazy {
      DrawableResource("drawable:strikethrough", setOf(
        ResourceItem(setOf(), "${MD}drawable/strikethrough.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_400_948_593)
public val Res.drawable.strikethrough_s: DrawableResource by lazy {
      DrawableResource("drawable:strikethrough_s", setOf(
        ResourceItem(setOf(), "${MD}drawable/strikethrough_s.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(996_907_360)
public val Res.drawable.subscript: DrawableResource by lazy {
      DrawableResource("drawable:subscript", setOf(
        ResourceItem(setOf(), "${MD}drawable/subscript.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-904_611_785)
public val Res.drawable.sun_moon: DrawableResource by lazy {
      DrawableResource("drawable:sun_moon", setOf(
        ResourceItem(setOf(), "${MD}drawable/sun_moon.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_218_906_380)
public val Res.drawable.superscript: DrawableResource by lazy {
      DrawableResource("drawable:superscript", setOf(
        ResourceItem(setOf(), "${MD}drawable/superscript.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-706_805_255)
public val Res.drawable.table: DrawableResource by lazy {
      DrawableResource("drawable:table", setOf(
        ResourceItem(setOf(), "${MD}drawable/table.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_920_131_841)
public val Res.drawable.tablet: DrawableResource by lazy {
      DrawableResource("drawable:tablet", setOf(
        ResourceItem(setOf(), "${MD}drawable/tablet.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-744_956_455)
public val Res.drawable.tag: DrawableResource by lazy {
      DrawableResource("drawable:tag", setOf(
        ResourceItem(setOf(), "${MD}drawable/tag.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-394_373_031)
public val Res.drawable.tags: DrawableResource by lazy {
      DrawableResource("drawable:tags", setOf(
        ResourceItem(setOf(), "${MD}drawable/tags.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_057_000_144)
public val Res.drawable.timer: DrawableResource by lazy {
      DrawableResource("drawable:timer", setOf(
        ResourceItem(setOf(), "${MD}drawable/timer.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_299_030_468)
public val Res.drawable.title: DrawableResource by lazy {
      DrawableResource("drawable:title", setOf(
        ResourceItem(setOf(), "${MD}drawable/title.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_807_501_581)
public val Res.drawable.trash_2: DrawableResource by lazy {
      DrawableResource("drawable:trash_2", setOf(
        ResourceItem(setOf(), "${MD}drawable/trash_2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_832_027_086)
public val Res.drawable.triangle_alert: DrawableResource by lazy {
      DrawableResource("drawable:triangle_alert", setOf(
        ResourceItem(setOf(), "${MD}drawable/triangle_alert.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(758_711_614)
public val Res.drawable.troubleshoot: DrawableResource by lazy {
      DrawableResource("drawable:troubleshoot", setOf(
        ResourceItem(setOf(), "${MD}drawable/troubleshoot.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-468_445_227)
public val Res.drawable.tune: DrawableResource by lazy {
      DrawableResource("drawable:tune", setOf(
        ResourceItem(setOf(), "${MD}drawable/tune.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-368_142_868)
public val Res.drawable.tv: DrawableResource by lazy {
      DrawableResource("drawable:tv", setOf(
        ResourceItem(setOf(), "${MD}drawable/tv.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-687_451_909)
public val Res.drawable.type: DrawableResource by lazy {
      DrawableResource("drawable:type", setOf(
        ResourceItem(setOf(), "${MD}drawable/type.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(940_064_952)
public val Res.drawable.underline: DrawableResource by lazy {
      DrawableResource("drawable:underline", setOf(
        ResourceItem(setOf(), "${MD}drawable/underline.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_933_434_195)
public val Res.drawable.undo: DrawableResource by lazy {
      DrawableResource("drawable:undo", setOf(
        ResourceItem(setOf(), "${MD}drawable/undo.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_528_296_595)
public val Res.drawable.undo_2: DrawableResource by lazy {
      DrawableResource("drawable:undo_2", setOf(
        ResourceItem(setOf(), "${MD}drawable/undo_2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_585_004_327)
public val Res.drawable.upload: DrawableResource by lazy {
      DrawableResource("drawable:upload", setOf(
        ResourceItem(setOf(), "${MD}drawable/upload.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_365_521_968)
public val Res.drawable.usb: DrawableResource by lazy {
      DrawableResource("drawable:usb", setOf(
        ResourceItem(setOf(), "${MD}drawable/usb.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_134_871_971)
public val Res.drawable.video: DrawableResource by lazy {
      DrawableResource("drawable:video", setOf(
        ResourceItem(setOf(), "${MD}drawable/video.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_093_808_491)
public val Res.drawable.volume_2: DrawableResource by lazy {
      DrawableResource("drawable:volume_2", setOf(
        ResourceItem(setOf(), "${MD}drawable/volume_2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_247_846_816)
public val Res.drawable.volume_x: DrawableResource by lazy {
      DrawableResource("drawable:volume_x", setOf(
        ResourceItem(setOf(), "${MD}drawable/volume_x.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_540_186_331)
public val Res.drawable.wifi: DrawableResource by lazy {
      DrawableResource("drawable:wifi", setOf(
        ResourceItem(setOf(), "${MD}drawable/wifi.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(328_473_571)
public val Res.drawable.wifi_tethering: DrawableResource by lazy {
      DrawableResource("drawable:wifi_tethering", setOf(
        ResourceItem(setOf(), "${MD}drawable/wifi_tethering.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(759_778_707)
public val Res.drawable.wrap_text: DrawableResource by lazy {
      DrawableResource("drawable:wrap_text", setOf(
        ResourceItem(setOf(), "${MD}drawable/wrap_text.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_650_059_502)
public val Res.drawable.x: DrawableResource by lazy {
      DrawableResource("drawable:x", setOf(
        ResourceItem(setOf(), "${MD}drawable/x.xml", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable1Resources(map: MutableMap<String, DrawableResource>) {
  map.put("launcher_background", Res.drawable.launcher_background)
  map.put("layers", Res.drawable.layers)
  map.put("layout_grid", Res.drawable.layout_grid)
  map.put("left_panel_close", Res.drawable.left_panel_close)
  map.put("left_panel_open", Res.drawable.left_panel_open)
  map.put("lightbulb", Res.drawable.lightbulb)
  map.put("link", Res.drawable.link)
  map.put("list_checks", Res.drawable.list_checks)
  map.put("list_music", Res.drawable.list_music)
  map.put("lock", Res.drawable.lock)
  map.put("looks_one", Res.drawable.looks_one)
  map.put("looks_two", Res.drawable.looks_two)
  map.put("markdown", Res.drawable.markdown)
  map.put("match_case", Res.drawable.match_case)
  map.put("maximize", Res.drawable.maximize)
  map.put("maximize_2", Res.drawable.maximize_2)
  map.put("menu", Res.drawable.menu)
  map.put("message_circle", Res.drawable.message_circle)
  map.put("message_square_text", Res.drawable.message_square_text)
  map.put("more_horiz", Res.drawable.more_horiz)
  map.put("more_three_dots", Res.drawable.more_three_dots)
  map.put("mouse_pointer", Res.drawable.mouse_pointer)
  map.put("music", Res.drawable.music)
  map.put("music2", Res.drawable.music2)
  map.put("notebook_pen", Res.drawable.notebook_pen)
  map.put("octagon_alert", Res.drawable.octagon_alert)
  map.put("package2", Res.drawable.package2)
  map.put("package_open", Res.drawable.package_open)
  map.put("paint_bucket", Res.drawable.paint_bucket)
  map.put("pause", Res.drawable.pause)
  map.put("pen", Res.drawable.pen)
  map.put("person", Res.drawable.person)
  map.put("phone_call", Res.drawable.phone_call)
  map.put("pip", Res.drawable.pip)
  map.put("play_arrow", Res.drawable.play_arrow)
  map.put("playlist_add", Res.drawable.playlist_add)
  map.put("playlist_check", Res.drawable.playlist_check)
  map.put("playlist_remove", Res.drawable.playlist_remove)
  map.put("plus", Res.drawable.plus)
  map.put("power_settings", Res.drawable.power_settings)
  map.put("print", Res.drawable.print)
  map.put("qr_code", Res.drawable.qr_code)
  map.put("redo", Res.drawable.redo)
  map.put("redo_2", Res.drawable.redo_2)
  map.put("refresh_ccw", Res.drawable.refresh_ccw)
  map.put("repeat", Res.drawable.repeat)
  map.put("repeat1", Res.drawable.repeat1)
  map.put("rocket", Res.drawable.rocket)
  map.put("rotate_ccw", Res.drawable.rotate_ccw)
  map.put("rotate_cw_square", Res.drawable.rotate_cw_square)
  map.put("rss", Res.drawable.rss)
  map.put("save", Res.drawable.save)
  map.put("scan_qr_code", Res.drawable.scan_qr_code)
  map.put("scissors", Res.drawable.scissors)
  map.put("sd_card", Res.drawable.sd_card)
  map.put("search", Res.drawable.search)
  map.put("select_all", Res.drawable.select_all)
  map.put("send", Res.drawable.send)
  map.put("settings", Res.drawable.settings)
  map.put("share_2", Res.drawable.share_2)
  map.put("shuffle", Res.drawable.shuffle)
  map.put("skip_next", Res.drawable.skip_next)
  map.put("skip_previous", Res.drawable.skip_previous)
  map.put("smartphone", Res.drawable.smartphone)
  map.put("sort", Res.drawable.sort)
  map.put("square", Res.drawable.square)
  map.put("square_arrow_out_up_right", Res.drawable.square_arrow_out_up_right)
  map.put("square_check", Res.drawable.square_check)
  map.put("square_pen", Res.drawable.square_pen)
  map.put("sticky_note", Res.drawable.sticky_note)
  map.put("strikethrough", Res.drawable.strikethrough)
  map.put("strikethrough_s", Res.drawable.strikethrough_s)
  map.put("subscript", Res.drawable.subscript)
  map.put("sun_moon", Res.drawable.sun_moon)
  map.put("superscript", Res.drawable.superscript)
  map.put("table", Res.drawable.table)
  map.put("tablet", Res.drawable.tablet)
  map.put("tag", Res.drawable.tag)
  map.put("tags", Res.drawable.tags)
  map.put("timer", Res.drawable.timer)
  map.put("title", Res.drawable.title)
  map.put("trash_2", Res.drawable.trash_2)
  map.put("triangle_alert", Res.drawable.triangle_alert)
  map.put("troubleshoot", Res.drawable.troubleshoot)
  map.put("tune", Res.drawable.tune)
  map.put("tv", Res.drawable.tv)
  map.put("type", Res.drawable.type)
  map.put("underline", Res.drawable.underline)
  map.put("undo", Res.drawable.undo)
  map.put("undo_2", Res.drawable.undo_2)
  map.put("upload", Res.drawable.upload)
  map.put("usb", Res.drawable.usb)
  map.put("video", Res.drawable.video)
  map.put("volume_2", Res.drawable.volume_2)
  map.put("volume_x", Res.drawable.volume_x)
  map.put("wifi", Res.drawable.wifi)
  map.put("wifi_tethering", Res.drawable.wifi_tethering)
  map.put("wrap_text", Res.drawable.wrap_text)
  map.put("x", Res.drawable.x)
}
