@file:OptIn(InternalResourceApi::class)

package com.ismartcoding.plain.ui.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/com.ismartcoding.plain.ui.resources/"

@delegate:ResourceContentHash(-570_906_192)
public val Res.drawable.add: DrawableResource by lazy {
      DrawableResource("drawable:add", setOf(
        ResourceItem(setOf(), "${MD}drawable/add.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(310_381_355)
public val Res.drawable.app_logo: DrawableResource by lazy {
      DrawableResource("drawable:app_logo", setOf(
        ResourceItem(setOf(), "${MD}drawable/app_logo.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_470_591_981)
public val Res.drawable.archive_restore: DrawableResource by lazy {
      DrawableResource("drawable:archive_restore", setOf(
        ResourceItem(setOf(), "${MD}drawable/archive_restore.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_000_800_270)
public val Res.drawable.arrow_down_to_line: DrawableResource by lazy {
      DrawableResource("drawable:arrow_down_to_line", setOf(
        ResourceItem(setOf(), "${MD}drawable/arrow_down_to_line.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_833_326_110)
public val Res.drawable.arrow_left: DrawableResource by lazy {
      DrawableResource("drawable:arrow_left", setOf(
        ResourceItem(setOf(), "${MD}drawable/arrow_left.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(961_270_332)
public val Res.drawable.arrow_right: DrawableResource by lazy {
      DrawableResource("drawable:arrow_right", setOf(
        ResourceItem(setOf(), "${MD}drawable/arrow_right.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_347_075_721)
public val Res.drawable.arrow_up_right: DrawableResource by lazy {
      DrawableResource("drawable:arrow_up_right", setOf(
        ResourceItem(setOf(), "${MD}drawable/arrow_up_right.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_590_083_027)
public val Res.drawable.arrow_up_to_line: DrawableResource by lazy {
      DrawableResource("drawable:arrow_up_to_line", setOf(
        ResourceItem(setOf(), "${MD}drawable/arrow_up_to_line.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-578_535_951)
public val Res.drawable.audio_lines: DrawableResource by lazy {
      DrawableResource("drawable:audio_lines", setOf(
        ResourceItem(setOf(), "${MD}drawable/audio_lines.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_364_535_257)
public val Res.drawable.bell: DrawableResource by lazy {
      DrawableResource("drawable:bell", setOf(
        ResourceItem(setOf(), "${MD}drawable/bell.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-992_748_769)
public val Res.drawable.bluetooth: DrawableResource by lazy {
      DrawableResource("drawable:bluetooth", setOf(
        ResourceItem(setOf(), "${MD}drawable/bluetooth.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-337_429_105)
public val Res.drawable.bold: DrawableResource by lazy {
      DrawableResource("drawable:bold", setOf(
        ResourceItem(setOf(), "${MD}drawable/bold.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(456_301_573)
public val Res.drawable.bookmark: DrawableResource by lazy {
      DrawableResource("drawable:bookmark", setOf(
        ResourceItem(setOf(), "${MD}drawable/bookmark.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_727_657_526)
public val Res.drawable.bot: DrawableResource by lazy {
      DrawableResource("drawable:bot", setOf(
        ResourceItem(setOf(), "${MD}drawable/bot.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-93_312_181)
public val Res.drawable.briefcase_business: DrawableResource by lazy {
      DrawableResource("drawable:briefcase_business", setOf(
        ResourceItem(setOf(), "${MD}drawable/briefcase_business.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(75_347_940)
public val Res.drawable.calculate: DrawableResource by lazy {
      DrawableResource("drawable:calculate", setOf(
        ResourceItem(setOf(), "${MD}drawable/calculate.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(612_191_957)
public val Res.drawable.call_log: DrawableResource by lazy {
      DrawableResource("drawable:call_log", setOf(
        ResourceItem(setOf(), "${MD}drawable/call_log.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_094_818_038)
public val Res.drawable.cast: DrawableResource by lazy {
      DrawableResource("drawable:cast", setOf(
        ResourceItem(setOf(), "${MD}drawable/cast.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_008_700_056)
public val Res.drawable.check: DrawableResource by lazy {
      DrawableResource("drawable:check", setOf(
        ResourceItem(setOf(), "${MD}drawable/check.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_111_273_412)
public val Res.drawable.checklist: DrawableResource by lazy {
      DrawableResource("drawable:checklist", setOf(
        ResourceItem(setOf(), "${MD}drawable/checklist.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_659_499_727)
public val Res.drawable.chevron_down: DrawableResource by lazy {
      DrawableResource("drawable:chevron_down", setOf(
        ResourceItem(setOf(), "${MD}drawable/chevron_down.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_138_981_167)
public val Res.drawable.chevron_left: DrawableResource by lazy {
      DrawableResource("drawable:chevron_left", setOf(
        ResourceItem(setOf(), "${MD}drawable/chevron_left.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-3_008_156)
public val Res.drawable.chevron_right: DrawableResource by lazy {
      DrawableResource("drawable:chevron_right", setOf(
        ResourceItem(setOf(), "${MD}drawable/chevron_right.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_566_480_227)
public val Res.drawable.chevron_up: DrawableResource by lazy {
      DrawableResource("drawable:chevron_up", setOf(
        ResourceItem(setOf(), "${MD}drawable/chevron_up.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_204_611_699)
public val Res.drawable.chrome: DrawableResource by lazy {
      DrawableResource("drawable:chrome", setOf(
        ResourceItem(setOf(), "${MD}drawable/chrome.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_283_604_756)
public val Res.drawable.circle: DrawableResource by lazy {
      DrawableResource("drawable:circle", setOf(
        ResourceItem(setOf(), "${MD}drawable/circle.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_936_666_411)
public val Res.drawable.circle_alert: DrawableResource by lazy {
      DrawableResource("drawable:circle_alert", setOf(
        ResourceItem(setOf(), "${MD}drawable/circle_alert.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_441_473_529)
public val Res.drawable.circle_check: DrawableResource by lazy {
      DrawableResource("drawable:circle_check", setOf(
        ResourceItem(setOf(), "${MD}drawable/circle_check.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(928_730_109)
public val Res.drawable.circle_dot: DrawableResource by lazy {
      DrawableResource("drawable:circle_dot", setOf(
        ResourceItem(setOf(), "${MD}drawable/circle_dot.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-453_263_576)
public val Res.drawable.circle_help: DrawableResource by lazy {
      DrawableResource("drawable:circle_help", setOf(
        ResourceItem(setOf(), "${MD}drawable/circle_help.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_064_484_669)
public val Res.drawable.circle_x: DrawableResource by lazy {
      DrawableResource("drawable:circle_x", setOf(
        ResourceItem(setOf(), "${MD}drawable/circle_x.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-142_749_684)
public val Res.drawable.close: DrawableResource by lazy {
      DrawableResource("drawable:close", setOf(
        ResourceItem(setOf(), "${MD}drawable/close.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_138_062_408)
public val Res.drawable.code: DrawableResource by lazy {
      DrawableResource("drawable:code", setOf(
        ResourceItem(setOf(), "${MD}drawable/code.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-363_802_963)
public val Res.drawable.code_blocks: DrawableResource by lazy {
      DrawableResource("drawable:code_blocks", setOf(
        ResourceItem(setOf(), "${MD}drawable/code_blocks.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(103_165_785)
public val Res.drawable.comment: DrawableResource by lazy {
      DrawableResource("drawable:comment", setOf(
        ResourceItem(setOf(), "${MD}drawable/comment.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_254_879_060)
public val Res.drawable.contact_round: DrawableResource by lazy {
      DrawableResource("drawable:contact_round", setOf(
        ResourceItem(setOf(), "${MD}drawable/contact_round.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_849_044_570)
public val Res.drawable.content_paste: DrawableResource by lazy {
      DrawableResource("drawable:content_paste", setOf(
        ResourceItem(setOf(), "${MD}drawable/content_paste.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(375_244_691)
public val Res.drawable.copy: DrawableResource by lazy {
      DrawableResource("drawable:copy", setOf(
        ResourceItem(setOf(), "${MD}drawable/copy.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(180_904_844)
public val Res.drawable.database_backup: DrawableResource by lazy {
      DrawableResource("drawable:database_backup", setOf(
        ResourceItem(setOf(), "${MD}drawable/database_backup.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_394_317_441)
public val Res.drawable.delete_forever: DrawableResource by lazy {
      DrawableResource("drawable:delete_forever", setOf(
        ResourceItem(setOf(), "${MD}drawable/delete_forever.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-609_699_705)
public val Res.drawable.demo_photo_1: DrawableResource by lazy {
      DrawableResource("drawable:demo_photo_1", setOf(
        ResourceItem(setOf(), "${MD}drawable/demo_photo_1.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(776_228_895)
public val Res.drawable.demo_photo_2: DrawableResource by lazy {
      DrawableResource("drawable:demo_photo_2", setOf(
        ResourceItem(setOf(), "${MD}drawable/demo_photo_2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-822_068_682)
public val Res.drawable.demo_photo_3: DrawableResource by lazy {
      DrawableResource("drawable:demo_photo_3", setOf(
        ResourceItem(setOf(), "${MD}drawable/demo_photo_3.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-283_934_603)
public val Res.drawable.demo_photo_4: DrawableResource by lazy {
      DrawableResource("drawable:demo_photo_4", setOf(
        ResourceItem(setOf(), "${MD}drawable/demo_photo_4.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-691_972_211)
public val Res.drawable.demo_photo_5: DrawableResource by lazy {
      DrawableResource("drawable:demo_photo_5", setOf(
        ResourceItem(setOf(), "${MD}drawable/demo_photo_5.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(803_900_077)
public val Res.drawable.demo_photo_6: DrawableResource by lazy {
      DrawableResource("drawable:demo_photo_6", setOf(
        ResourceItem(setOf(), "${MD}drawable/demo_photo_6.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(566_006_533)
public val Res.drawable.devices: DrawableResource by lazy {
      DrawableResource("drawable:devices", setOf(
        ResourceItem(setOf(), "${MD}drawable/devices.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_830_014_273)
public val Res.drawable.double_arrow_right: DrawableResource by lazy {
      DrawableResource("drawable:double_arrow_right", setOf(
        ResourceItem(setOf(), "${MD}drawable/double_arrow_right.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-530_587_053)
public val Res.drawable.download: DrawableResource by lazy {
      DrawableResource("drawable:download", setOf(
        ResourceItem(setOf(), "${MD}drawable/download.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-224_759_100)
public val Res.drawable.ellipsis: DrawableResource by lazy {
      DrawableResource("drawable:ellipsis", setOf(
        ResourceItem(setOf(), "${MD}drawable/ellipsis.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_492_759_758)
public val Res.drawable.ellipsis_vertical: DrawableResource by lazy {
      DrawableResource("drawable:ellipsis_vertical", setOf(
        ResourceItem(setOf(), "${MD}drawable/ellipsis_vertical.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(793_745_522)
public val Res.drawable.equal: DrawableResource by lazy {
      DrawableResource("drawable:equal", setOf(
        ResourceItem(setOf(), "${MD}drawable/equal.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_493_657_081)
public val Res.drawable.expand_more: DrawableResource by lazy {
      DrawableResource("drawable:expand_more", setOf(
        ResourceItem(setOf(), "${MD}drawable/expand_more.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_052_070_191)
public val Res.drawable.eye: DrawableResource by lazy {
      DrawableResource("drawable:eye", setOf(
        ResourceItem(setOf(), "${MD}drawable/eye.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(431_897_184)
public val Res.drawable.eye_off: DrawableResource by lazy {
      DrawableResource("drawable:eye_off", setOf(
        ResourceItem(setOf(), "${MD}drawable/eye_off.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-516_366_036)
public val Res.drawable.`file`: DrawableResource by lazy {
      DrawableResource("drawable:file", setOf(
        ResourceItem(setOf(), "${MD}drawable/file.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_008_774_866)
public val Res.drawable.file_digit: DrawableResource by lazy {
      DrawableResource("drawable:file_digit", setOf(
        ResourceItem(setOf(), "${MD}drawable/file_digit.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-44_171_648)
public val Res.drawable.file_plus: DrawableResource by lazy {
      DrawableResource("drawable:file_plus", setOf(
        ResourceItem(setOf(), "${MD}drawable/file_plus.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(820_731_097)
public val Res.drawable.file_question: DrawableResource by lazy {
      DrawableResource("drawable:file_question", setOf(
        ResourceItem(setOf(), "${MD}drawable/file_question.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_953_836_255)
public val Res.drawable.file_text: DrawableResource by lazy {
      DrawableResource("drawable:file_text", setOf(
        ResourceItem(setOf(), "${MD}drawable/file_text.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(959_074_958)
public val Res.drawable.file_video: DrawableResource by lazy {
      DrawableResource("drawable:file_video", setOf(
        ResourceItem(setOf(), "${MD}drawable/file_video.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-155_351_321)
public val Res.drawable.files: DrawableResource by lazy {
      DrawableResource("drawable:files", setOf(
        ResourceItem(setOf(), "${MD}drawable/files.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_871_531_611)
public val Res.drawable.folder: DrawableResource by lazy {
      DrawableResource("drawable:folder", setOf(
        ResourceItem(setOf(), "${MD}drawable/folder.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-219_452_255)
public val Res.drawable.folder_kanban: DrawableResource by lazy {
      DrawableResource("drawable:folder_kanban", setOf(
        ResourceItem(setOf(), "${MD}drawable/folder_kanban.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_059_371_006)
public val Res.drawable.folder_plus: DrawableResource by lazy {
      DrawableResource("drawable:folder_plus", setOf(
        ResourceItem(setOf(), "${MD}drawable/folder_plus.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_283_585_878)
public val Res.drawable.folders: DrawableResource by lazy {
      DrawableResource("drawable:folders", setOf(
        ResourceItem(setOf(), "${MD}drawable/folders.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-569_034_493)
public val Res.drawable.format_bold: DrawableResource by lazy {
      DrawableResource("drawable:format_bold", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_bold.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_084_723_223)
public val Res.drawable.format_clear: DrawableResource by lazy {
      DrawableResource("drawable:format_clear", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_clear.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_479_579_789)
public val Res.drawable.format_color_fill: DrawableResource by lazy {
      DrawableResource("drawable:format_color_fill", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_color_fill.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_098_018_478)
public val Res.drawable.format_h1: DrawableResource by lazy {
      DrawableResource("drawable:format_h1", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_h1.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(454_618_569)
public val Res.drawable.format_h2: DrawableResource by lazy {
      DrawableResource("drawable:format_h2", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_h2.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_880_493_517)
public val Res.drawable.format_h3: DrawableResource by lazy {
      DrawableResource("drawable:format_h3", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_h3.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-843_007_888)
public val Res.drawable.format_h4: DrawableResource by lazy {
      DrawableResource("drawable:format_h4", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_h4.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_279_208_221)
public val Res.drawable.format_h5: DrawableResource by lazy {
      DrawableResource("drawable:format_h5", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_h5.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(346_685_910)
public val Res.drawable.format_h6: DrawableResource by lazy {
      DrawableResource("drawable:format_h6", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_h6.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(816_950_750)
public val Res.drawable.format_italic: DrawableResource by lazy {
      DrawableResource("drawable:format_italic", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_italic.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_835_538_429)
public val Res.drawable.format_list_bulleted: DrawableResource by lazy {
      DrawableResource("drawable:format_list_bulleted", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_list_bulleted.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_617_636_194)
public val Res.drawable.format_list_numbered: DrawableResource by lazy {
      DrawableResource("drawable:format_list_numbered", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_list_numbered.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(975_136_361)
public val Res.drawable.format_quote: DrawableResource by lazy {
      DrawableResource("drawable:format_quote", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_quote.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(329_042_722)
public val Res.drawable.format_underlined: DrawableResource by lazy {
      DrawableResource("drawable:format_underlined", setOf(
        ResourceItem(setOf(), "${MD}drawable/format_underlined.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_758_107_453)
public val Res.drawable.forward: DrawableResource by lazy {
      DrawableResource("drawable:forward", setOf(
        ResourceItem(setOf(), "${MD}drawable/forward.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_044_912_951)
public val Res.drawable.fullscreen: DrawableResource by lazy {
      DrawableResource("drawable:fullscreen", setOf(
        ResourceItem(setOf(), "${MD}drawable/fullscreen.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_001_635_316)
public val Res.drawable.fullscreen_exit: DrawableResource by lazy {
      DrawableResource("drawable:fullscreen_exit", setOf(
        ResourceItem(setOf(), "${MD}drawable/fullscreen_exit.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(67_934_612)
public val Res.drawable.functions: DrawableResource by lazy {
      DrawableResource("drawable:functions", setOf(
        ResourceItem(setOf(), "${MD}drawable/functions.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(939_999_495)
public val Res.drawable.gauge: DrawableResource by lazy {
      DrawableResource("drawable:gauge", setOf(
        ResourceItem(setOf(), "${MD}drawable/gauge.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_568_447_785)
public val Res.drawable.grid_3x3: DrawableResource by lazy {
      DrawableResource("drawable:grid_3x3", setOf(
        ResourceItem(setOf(), "${MD}drawable/grid_3x3.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_182_648_534)
public val Res.drawable.hard_drive: DrawableResource by lazy {
      DrawableResource("drawable:hard_drive", setOf(
        ResourceItem(setOf(), "${MD}drawable/hard_drive.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_641_331_028)
public val Res.drawable.hash: DrawableResource by lazy {
      DrawableResource("drawable:hash", setOf(
        ResourceItem(setOf(), "${MD}drawable/hash.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_796_815_568)
public val Res.drawable.highlight: DrawableResource by lazy {
      DrawableResource("drawable:highlight", setOf(
        ResourceItem(setOf(), "${MD}drawable/highlight.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_126_017_710)
public val Res.drawable.highlighter: DrawableResource by lazy {
      DrawableResource("drawable:highlighter", setOf(
        ResourceItem(setOf(), "${MD}drawable/highlighter.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_711_510_319)
public val Res.drawable.history: DrawableResource by lazy {
      DrawableResource("drawable:history", setOf(
        ResourceItem(setOf(), "${MD}drawable/history.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_175_058_185)
public val Res.drawable.horizontal_rule: DrawableResource by lazy {
      DrawableResource("drawable:horizontal_rule", setOf(
        ResourceItem(setOf(), "${MD}drawable/horizontal_rule.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_020_064_130)
public val Res.drawable.house: DrawableResource by lazy {
      DrawableResource("drawable:house", setOf(
        ResourceItem(setOf(), "${MD}drawable/house.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-294_506_312)
public val Res.drawable.image: DrawableResource by lazy {
      DrawableResource("drawable:image", setOf(
        ResourceItem(setOf(), "${MD}drawable/image.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_004_951_441)
public val Res.drawable.info: DrawableResource by lazy {
      DrawableResource("drawable:info", setOf(
        ResourceItem(setOf(), "${MD}drawable/info.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_659_798_107)
public val Res.drawable.italic: DrawableResource by lazy {
      DrawableResource("drawable:italic", setOf(
        ResourceItem(setOf(), "${MD}drawable/italic.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_178_007_290)
public val Res.drawable.label: DrawableResource by lazy {
      DrawableResource("drawable:label", setOf(
        ResourceItem(setOf(), "${MD}drawable/label.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-850_789_903)
public val Res.drawable.label_off: DrawableResource by lazy {
      DrawableResource("drawable:label_off", setOf(
        ResourceItem(setOf(), "${MD}drawable/label_off.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_329_581_814)
public val Res.drawable.languages: DrawableResource by lazy {
      DrawableResource("drawable:languages", setOf(
        ResourceItem(setOf(), "${MD}drawable/languages.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-648_615_503)
public val Res.drawable.laptop: DrawableResource by lazy {
      DrawableResource("drawable:laptop", setOf(
        ResourceItem(setOf(), "${MD}drawable/laptop.xml", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("add", Res.drawable.add)
  map.put("app_logo", Res.drawable.app_logo)
  map.put("archive_restore", Res.drawable.archive_restore)
  map.put("arrow_down_to_line", Res.drawable.arrow_down_to_line)
  map.put("arrow_left", Res.drawable.arrow_left)
  map.put("arrow_right", Res.drawable.arrow_right)
  map.put("arrow_up_right", Res.drawable.arrow_up_right)
  map.put("arrow_up_to_line", Res.drawable.arrow_up_to_line)
  map.put("audio_lines", Res.drawable.audio_lines)
  map.put("bell", Res.drawable.bell)
  map.put("bluetooth", Res.drawable.bluetooth)
  map.put("bold", Res.drawable.bold)
  map.put("bookmark", Res.drawable.bookmark)
  map.put("bot", Res.drawable.bot)
  map.put("briefcase_business", Res.drawable.briefcase_business)
  map.put("calculate", Res.drawable.calculate)
  map.put("call_log", Res.drawable.call_log)
  map.put("cast", Res.drawable.cast)
  map.put("check", Res.drawable.check)
  map.put("checklist", Res.drawable.checklist)
  map.put("chevron_down", Res.drawable.chevron_down)
  map.put("chevron_left", Res.drawable.chevron_left)
  map.put("chevron_right", Res.drawable.chevron_right)
  map.put("chevron_up", Res.drawable.chevron_up)
  map.put("chrome", Res.drawable.chrome)
  map.put("circle", Res.drawable.circle)
  map.put("circle_alert", Res.drawable.circle_alert)
  map.put("circle_check", Res.drawable.circle_check)
  map.put("circle_dot", Res.drawable.circle_dot)
  map.put("circle_help", Res.drawable.circle_help)
  map.put("circle_x", Res.drawable.circle_x)
  map.put("close", Res.drawable.close)
  map.put("code", Res.drawable.code)
  map.put("code_blocks", Res.drawable.code_blocks)
  map.put("comment", Res.drawable.comment)
  map.put("contact_round", Res.drawable.contact_round)
  map.put("content_paste", Res.drawable.content_paste)
  map.put("copy", Res.drawable.copy)
  map.put("database_backup", Res.drawable.database_backup)
  map.put("delete_forever", Res.drawable.delete_forever)
  map.put("demo_photo_1", Res.drawable.demo_photo_1)
  map.put("demo_photo_2", Res.drawable.demo_photo_2)
  map.put("demo_photo_3", Res.drawable.demo_photo_3)
  map.put("demo_photo_4", Res.drawable.demo_photo_4)
  map.put("demo_photo_5", Res.drawable.demo_photo_5)
  map.put("demo_photo_6", Res.drawable.demo_photo_6)
  map.put("devices", Res.drawable.devices)
  map.put("double_arrow_right", Res.drawable.double_arrow_right)
  map.put("download", Res.drawable.download)
  map.put("ellipsis", Res.drawable.ellipsis)
  map.put("ellipsis_vertical", Res.drawable.ellipsis_vertical)
  map.put("equal", Res.drawable.equal)
  map.put("expand_more", Res.drawable.expand_more)
  map.put("eye", Res.drawable.eye)
  map.put("eye_off", Res.drawable.eye_off)
  map.put("file", Res.drawable.`file`)
  map.put("file_digit", Res.drawable.file_digit)
  map.put("file_plus", Res.drawable.file_plus)
  map.put("file_question", Res.drawable.file_question)
  map.put("file_text", Res.drawable.file_text)
  map.put("file_video", Res.drawable.file_video)
  map.put("files", Res.drawable.files)
  map.put("folder", Res.drawable.folder)
  map.put("folder_kanban", Res.drawable.folder_kanban)
  map.put("folder_plus", Res.drawable.folder_plus)
  map.put("folders", Res.drawable.folders)
  map.put("format_bold", Res.drawable.format_bold)
  map.put("format_clear", Res.drawable.format_clear)
  map.put("format_color_fill", Res.drawable.format_color_fill)
  map.put("format_h1", Res.drawable.format_h1)
  map.put("format_h2", Res.drawable.format_h2)
  map.put("format_h3", Res.drawable.format_h3)
  map.put("format_h4", Res.drawable.format_h4)
  map.put("format_h5", Res.drawable.format_h5)
  map.put("format_h6", Res.drawable.format_h6)
  map.put("format_italic", Res.drawable.format_italic)
  map.put("format_list_bulleted", Res.drawable.format_list_bulleted)
  map.put("format_list_numbered", Res.drawable.format_list_numbered)
  map.put("format_quote", Res.drawable.format_quote)
  map.put("format_underlined", Res.drawable.format_underlined)
  map.put("forward", Res.drawable.forward)
  map.put("fullscreen", Res.drawable.fullscreen)
  map.put("fullscreen_exit", Res.drawable.fullscreen_exit)
  map.put("functions", Res.drawable.functions)
  map.put("gauge", Res.drawable.gauge)
  map.put("grid_3x3", Res.drawable.grid_3x3)
  map.put("hard_drive", Res.drawable.hard_drive)
  map.put("hash", Res.drawable.hash)
  map.put("highlight", Res.drawable.highlight)
  map.put("highlighter", Res.drawable.highlighter)
  map.put("history", Res.drawable.history)
  map.put("horizontal_rule", Res.drawable.horizontal_rule)
  map.put("house", Res.drawable.house)
  map.put("image", Res.drawable.image)
  map.put("info", Res.drawable.info)
  map.put("italic", Res.drawable.italic)
  map.put("label", Res.drawable.label)
  map.put("label_off", Res.drawable.label_off)
  map.put("languages", Res.drawable.languages)
  map.put("laptop", Res.drawable.laptop)
}
