@file:OptIn(InternalResourceApi::class)

package com.ismartcoding.plain.ui.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.RegionQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.ismartcoding.plain.ui.resources/"

@delegate:ResourceContentHash(-158_565_974)
public val Res.string.back: StringResource by lazy {
      StringResource("string:back", "back", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 10, 32),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 10, 24),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 10, 28),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 10, 24),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 10, 28),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 10, 28),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 10, 28),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 10, 20),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 10, 20),
      ))
    }

@delegate:ResourceContentHash(-1_160_468_230)
public val Res.string.clear: StringResource by lazy {
      StringResource("string:clear", "clear", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 43, 45),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 35, 25),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 31, 25),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 31, 25),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 39, 29),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 35, 25),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 31, 25),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 31, 25),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 31, 25),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 31, 21),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 39, 37),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 39, 25),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 31, 25),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 39, 21),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 31, 21),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 31, 21),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 31, 21),
      ))
    }

@delegate:ResourceContentHash(-30_066_109)
public val Res.string.copy_text: StringResource by lazy {
      StringResource("string:copy_text", "copy_text", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 89, 93),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 61, 37),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 57, 33),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 57, 37),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 69, 97),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 61, 33),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 57, 49),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 57, 41),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 57, 37),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 53, 33),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 77, 61),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 65, 69),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 57, 37),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 61, 45),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 53, 33),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 53, 33),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 53, 29),
      ))
    }

@delegate:ResourceContentHash(-1_031_175_383)
public val Res.string.delete: StringResource by lazy {
      StringResource("string:delete", "delete", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 183, 54),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 99, 26),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 91, 26),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 95, 26),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 167, 34),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 95, 26),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 107, 22),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 99, 22),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 95, 30),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 87, 22),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 139, 34),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 135, 38),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 95, 18),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 107, 22),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 87, 22),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 87, 22),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 83, 22),
      ))
    }

@delegate:ResourceContentHash(315_353_558)
public val Res.string.hide_password: StringResource by lazy {
      StringResource("string:hide_password", "hide_password", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 110, 37),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 106, 41),
      ))
    }

@delegate:ResourceContentHash(-2_010_031_908)
public val Res.string.loading: StringResource by lazy {
      StringResource("string:loading", "loading", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 238, 55),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 126, 27),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 118, 31),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 122, 47),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 202, 63),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 122, 35),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 130, 35),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 122, 35),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 126, 27),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 110, 35),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 174, 43),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 174, 59),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 114, 35),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 130, 35),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 148, 31),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 110, 31),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 148, 31),
      ))
    }

@delegate:ResourceContentHash(-1_865_503_300)
public val Res.string.no_data: StringResource by lazy {
      StringResource("string:no_data", "no_data", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 294, 59),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 154, 31),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 150, 27),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 170, 35),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 266, 63),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 158, 31),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 166, 35),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 158, 39),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 154, 35),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 146, 27),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 218, 43),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 234, 67),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 150, 27),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 166, 47),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 180, 31),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 142, 31),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 180, 27),
      ))
    }

@delegate:ResourceContentHash(1_856_462_690)
public val Res.string.no_results_found: StringResource by lazy {
      StringResource("string:no_results_found", "no_results_found", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 354, 104),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 186, 60),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 178, 64),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 206, 56),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 330, 96),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 190, 56),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 202, 76),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 198, 56),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 190, 56),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 174, 60),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 262, 80),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 302, 152),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 178, 48),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 214, 64),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 212, 44),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 174, 44),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 208, 48),
      ))
    }

@delegate:ResourceContentHash(588_593_141)
public val Res.string.password: StringResource by lazy {
      StringResource("string:password", "password", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 459, 56),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 247, 28),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 243, 32),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 263, 32),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 427, 44),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 247, 28),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 279, 36),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 255, 32),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 247, 32),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 235, 24),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 343, 32),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 455, 56),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 227, 24),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 279, 32),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 257, 24),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 219, 24),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 257, 28),
      ))
    }

@delegate:ResourceContentHash(-1_724_138_346)
public val Res.string.paste: StringResource by lazy {
      StringResource("string:paste", "paste", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 516, 53),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 276, 25),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 276, 21),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 296, 21),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 472, 53),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 276, 25),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 316, 29),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 288, 29),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 280, 25),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 260, 21),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 376, 37),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 512, 73),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 252, 29),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 312, 21),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 282, 21),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 244, 21),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 286, 21),
      ))
    }

@delegate:ResourceContentHash(-594_658_365)
public val Res.string.searching: StringResource by lazy {
      StringResource("string:searching", "searching", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 570, 93),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 302, 29),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 298, 33),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 318, 45),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 526, 57),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 302, 33),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 346, 33),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 318, 37),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 306, 29),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 282, 37),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 414, 37),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 586, 57),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 282, 33),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 334, 45),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 304, 33),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 266, 33),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 308, 33),
      ))
    }

@delegate:ResourceContentHash(2_055_796_364)
public val Res.string.show_password: StringResource by lazy {
      StringResource("string:show_password", "show_password", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 338, 37),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 342, 41),
      ))
    }

@delegate:ResourceContentHash(84_525_364)
public val Res.string.srl_header_failed: StringResource by lazy {
      StringResource("string:srl_header_failed", "srl_header_failed", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 664, 105),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 332, 65),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 332, 49),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 364, 61),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 584, 117),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 336, 53),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 380, 61),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 356, 53),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 336, 49),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 320, 57),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 452, 81),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 644, 97),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 316, 53),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 380, 57),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 376, 41),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 300, 41),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 384, 45),
      ))
    }

@delegate:ResourceContentHash(2_146_076_225)
public val Res.string.srl_header_finish: StringResource by lazy {
      StringResource("string:srl_header_finish", "srl_header_finish", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 770, 81),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 398, 41),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 382, 41),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 426, 41),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 702, 69),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 390, 41),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 442, 41),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 410, 49),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 386, 37),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 378, 41),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 534, 49),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 742, 117),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 370, 37),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 438, 45),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 418, 41),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 342, 41),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 430, 37),
      ))
    }

@delegate:ResourceContentHash(-154_473_114)
public val Res.string.srl_header_last_refresh_days: StringResource by lazy {
      StringResource("string:srl_header_last_refresh_days", "srl_header_last_refresh_days", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 460, 72),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 468, 72),
      ))
    }

@delegate:ResourceContentHash(-958_313_830)
public val Res.string.srl_header_last_refresh_hours: StringResource by lazy {
      StringResource("string:srl_header_last_refresh_hours", "srl_header_last_refresh_hours", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 533, 77),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 541, 73),
      ))
    }

@delegate:ResourceContentHash(-1_249_116_746)
public val Res.string.srl_header_last_refresh_just_now: StringResource by lazy {
      StringResource("string:srl_header_last_refresh_just_now", "srl_header_last_refresh_just_now", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 611, 68),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 615, 72),
      ))
    }

@delegate:ResourceContentHash(-790_141_994)
public val Res.string.srl_header_last_refresh_minutes: StringResource by lazy {
      StringResource("string:srl_header_last_refresh_minutes", "srl_header_last_refresh_minutes", setOf(
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 680, 79),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 688, 75),
      ))
    }

@delegate:ResourceContentHash(259_796_772)
public val Res.string.srl_header_pulling: StringResource by lazy {
      StringResource("string:srl_header_pulling", "srl_header_pulling", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 852, 78),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 440, 74),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 424, 74),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 468, 74),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 772, 130),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 432, 74),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 484, 62),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 460, 66),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 424, 66),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 420, 66),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 584, 98),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 860, 130),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 408, 70),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 484, 66),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 760, 50),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 384, 50),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 764, 54),
      ))
    }

@delegate:ResourceContentHash(-902_543_031)
public val Res.string.srl_header_refreshing: StringResource by lazy {
      StringResource("string:srl_header_refreshing", "srl_header_refreshing", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 931, 85),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 515, 49),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 499, 49),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 543, 65),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 903, 105),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 507, 53),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 547, 45),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 527, 57),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 491, 49),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 487, 49),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 683, 61),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 991, 125),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 479, 49),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 551, 57),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 811, 49),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 435, 49),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 819, 49),
      ))
    }

@delegate:ResourceContentHash(1_828_696_498)
public val Res.string.srl_header_release: StringResource by lazy {
      StringResource("string:srl_header_release", "srl_header_release", setOf(
        ResourceItem(setOf(LanguageQualifier("bn"), ), "${MD}values-bn/strings_components.commonMain.cvr", 1017, 66),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings_components.commonMain.cvr", 565, 62),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings_components.commonMain.cvr", 549, 54),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings_components.commonMain.cvr", 609, 62),
        ResourceItem(setOf(LanguageQualifier("hi"), ), "${MD}values-hi/strings_components.commonMain.cvr", 1009, 114),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings_components.commonMain.cvr", 561, 58),
        ResourceItem(setOf(LanguageQualifier("ja"), ), "${MD}values-ja/strings_components.commonMain.cvr", 593, 70),
        ResourceItem(setOf(LanguageQualifier("ko"), ), "${MD}values-ko/strings_components.commonMain.cvr", 585, 74),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings_components.commonMain.cvr", 541, 62),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings_components.commonMain.cvr", 537, 54),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings_components.commonMain.cvr", 745, 90),
        ResourceItem(setOf(LanguageQualifier("ta"), ), "${MD}values-ta/strings_components.commonMain.cvr", 1117, 122),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings_components.commonMain.cvr", 529, 62),
        ResourceItem(setOf(LanguageQualifier("vi"), ), "${MD}values-vi/strings_components.commonMain.cvr", 609, 58),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings_components.commonMain.cvr", 861, 50),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings_components.commonMain.cvr", 485, 50),
        ResourceItem(setOf(), "${MD}values/strings_components.commonMain.cvr", 869, 50),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("back", Res.string.back)
  map.put("clear", Res.string.clear)
  map.put("copy_text", Res.string.copy_text)
  map.put("delete", Res.string.delete)
  map.put("hide_password", Res.string.hide_password)
  map.put("loading", Res.string.loading)
  map.put("no_data", Res.string.no_data)
  map.put("no_results_found", Res.string.no_results_found)
  map.put("password", Res.string.password)
  map.put("paste", Res.string.paste)
  map.put("searching", Res.string.searching)
  map.put("show_password", Res.string.show_password)
  map.put("srl_header_failed", Res.string.srl_header_failed)
  map.put("srl_header_finish", Res.string.srl_header_finish)
  map.put("srl_header_last_refresh_days", Res.string.srl_header_last_refresh_days)
  map.put("srl_header_last_refresh_hours", Res.string.srl_header_last_refresh_hours)
  map.put("srl_header_last_refresh_just_now", Res.string.srl_header_last_refresh_just_now)
  map.put("srl_header_last_refresh_minutes", Res.string.srl_header_last_refresh_minutes)
  map.put("srl_header_pulling", Res.string.srl_header_pulling)
  map.put("srl_header_refreshing", Res.string.srl_header_refreshing)
  map.put("srl_header_release", Res.string.srl_header_release)
}
